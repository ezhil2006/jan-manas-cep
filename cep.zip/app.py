"""
JAN-MANAS: Civic Sentiment & Urgency Analyzer
Brihanmumbai Municipal Corporation (BMC) - F-North Ward (GTB Nagar / Sion Koliwada).

Tabs:
1. Citizen Grievance Portal (Public-facing reporting with real-time NLP preview & tracking token)
2. GTB Nagar Hotspot Map (Pydeck 3D map with urgency color-coding)
3. Ward Officer Command Deck (Priority triage, Kanban KPI counters, WhatsApp dispatcher, CSV export)
4. Academic XAI & Analytics Desk (Plotly visualizations, interactive testing sandbox, validation benchmarks)
"""

import streamlit as st
import pandas as pd
import pydeck as pdk
import plotly.express as px
import plotly.graph_objects as go
from urllib.parse import quote
from datetime import datetime

from utils.db_manager import (
    DatabaseManager,
    VALID_CLUSTERS,
    VALID_DEPARTMENTS,
    VALID_URGENCY,
    VALID_STATUS,
    LOCALITY_OPTIONS,
    LOCALITY_TO_CLUSTER,
    GTB_NAGAR_CENTER,
    get_item_coordinates,
    generate_tracking_token
)
from models.sentiment_engine import analyze_civic_sentiment
from models.department_classifier import department_classifier
from models.urgency_scorer import calculate_urgency
from models.xai_engine import xai_engine, ACADEMIC_VALIDATION_METRICS

# Set Page Configuration
st.set_page_config(
    page_title="JAN-MANAS | BMC F-North Ward",
    page_icon="🏛️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Initialize Database Singleton & Auto-seed
@st.cache_resource
def get_db():
    db = DatabaseManager()
    db.seed_database_if_empty()
    return db

db = get_db()

# Custom CSS for Modern Civic Municipal Aesthetics
st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
    
    html, body, [class*="css"] {
        font-family: 'Inter', sans-serif;
    }

    /* Municipal Hero Card */
    .hero-banner {
        background: linear-gradient(135deg, #0F172A 0%, #1E3A8A 50%, #2563EB 100%);
        padding: 24px 30px;
        border-radius: 12px;
        color: white;
        margin-bottom: 22px;
        box-shadow: 0 4px 15px rgba(30, 58, 138, 0.2);
    }
    .hero-title {
        font-size: 1.85rem;
        font-weight: 800;
        letter-spacing: -0.5px;
        color: #FFFFFF !important;
        margin: 6px 0 2px 0;
    }
    .hero-subtitle {
        font-size: 0.95rem;
        color: #93C5FD;
        margin-bottom: 0px;
    }
    .hero-badge {
        background: #DC2626;
        color: #FFFFFF;
        padding: 3px 10px;
        border-radius: 20px;
        font-size: 0.72rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.6px;
        display: inline-block;
    }
    .helpline-box {
        background: rgba(255, 255, 255, 0.12);
        border: 1px solid rgba(255, 255, 255, 0.25);
        border-radius: 10px;
        padding: 10px 18px;
        text-align: right;
        backdrop-filter: blur(8px);
    }

    /* Kanban KPI Cards */
    .kanban-card {
        border-radius: 10px;
        padding: 16px 20px;
        box-shadow: 0 2px 6px rgba(0,0,0,0.05);
        border-left: 5px solid;
        background: #FFFFFF;
    }
    .kanban-title {
        font-size: 0.78rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.8px;
        color: #64748B;
        margin-bottom: 4px;
    }
    .kanban-count {
        font-size: 1.85rem;
        font-weight: 800;
        line-height: 1.1;
    }

    /* Real-time Preview Card */
    .preview-container {
        background: #F8FAFC;
        border: 1px solid #E2E8F0;
        border-radius: 12px;
        padding: 20px;
        margin-top: 15px;
        margin-bottom: 20px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.04);
    }
    .preview-header {
        font-size: 0.85rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.8px;
        color: #64748B;
        margin-bottom: 12px;
        display: flex;
        align-items: center;
        gap: 6px;
    }

    /* Status & Urgency Badges */
    .badge-high {
        background-color: #FEE2E2;
        color: #991B1B;
        border: 1px solid #F87171;
        padding: 5px 12px;
        border-radius: 20px;
        font-weight: 700;
        font-size: 0.85rem;
        display: inline-flex;
        align-items: center;
        gap: 6px;
    }
    .badge-medium {
        background-color: #FEF3C7;
        color: #92400E;
        border: 1px solid #FBBF24;
        padding: 5px 12px;
        border-radius: 20px;
        font-weight: 700;
        font-size: 0.85rem;
        display: inline-flex;
        align-items: center;
        gap: 6px;
    }
    .badge-low {
        background-color: #D1FAE5;
        color: #065F46;
        border: 1px solid #34D399;
        padding: 5px 12px;
        border-radius: 20px;
        font-weight: 700;
        font-size: 0.85rem;
        display: inline-flex;
        align-items: center;
        gap: 6px;
    }
    .badge-frustrated {
        background-color: #FFE4E6;
        color: #9F1239;
        padding: 4px 10px;
        border-radius: 6px;
        font-weight: 600;
        font-size: 0.82rem;
    }
    .badge-concern {
        background-color: #FEF9C3;
        color: #854D0E;
        padding: 4px 10px;
        border-radius: 6px;
        font-weight: 600;
        font-size: 0.82rem;
    }
    .badge-satisfied {
        background-color: #ECFDF5;
        color: #065F46;
        padding: 4px 10px;
        border-radius: 6px;
        font-weight: 600;
        font-size: 0.82rem;
    }

    /* Success Card */
    .token-card {
        background: #F0FDF4;
        border: 1.5px solid #86EFAC;
        border-radius: 10px;
        padding: 18px 24px;
        margin: 15px 0;
    }
    .token-id {
        font-family: monospace;
        font-size: 1.35rem;
        font-weight: 800;
        color: #166534;
        background: #DCFCE7;
        padding: 4px 12px;
        border-radius: 6px;
        display: inline-block;
        margin: 6px 0;
    }

    /* WhatsApp Dispatch Box */
    .whatsapp-box {
        background: #F0FDF4;
        border: 1px solid #BBF7D0;
        border-radius: 10px;
        padding: 16px;
        margin-top: 10px;
    }

    /* Academic Cards */
    .academic-banner {
        background: linear-gradient(135deg, #1E1B4B 0%, #312E81 50%, #4338CA 100%);
        padding: 20px 24px;
        border-radius: 12px;
        color: white;
        margin-bottom: 20px;
    }
</style>
""", unsafe_allow_html=True)

# Sidebar: Controls, Ward Info & Database Management
st.sidebar.markdown("### 🏛️ BMC F-North Ward")
st.sidebar.caption("Guru Tegh Bahadur (GTB) Nagar / Sion Koliwada")
st.sidebar.markdown("---")

st.sidebar.subheader("🔍 Global Filters")
sidebar_cluster = st.sidebar.selectbox("Filter Locality Cluster", ["All"] + list(dict.fromkeys(VALID_CLUSTERS)))
sidebar_dept = st.sidebar.selectbox("Filter BMC Department", ["All"] + VALID_DEPARTMENTS)
sidebar_urgency = st.sidebar.selectbox("Filter Urgency", ["All"] + VALID_URGENCY)
sidebar_status = st.sidebar.selectbox("Filter Status", ["All"] + VALID_STATUS)
sidebar_search = st.sidebar.text_input("Search Grievances", "")

st.sidebar.markdown("---")
st.sidebar.subheader("⚙️ System Operations")
if st.sidebar.button("🔄 Reset & Seed 25 GTB Nagar Items", use_container_width=True):
    db.reset_database()
    db.seed_database_if_empty()
    st.sidebar.success("Database restored with 25 realistic GTB Nagar complaints!")
    st.rerun()

# Top Navigation Tabs
tab_citizen, tab_map, tab_command, tab_xai = st.tabs([
    "📢 Citizen Grievance Portal",
    "🗺️ GTB Nagar Hotspot Map",
    "🛡️ Ward Officer Command Deck",
    "🎓 Academic XAI & Analytics Desk"
])

# ==============================================================================
# TAB 1: CITIZEN GRIEVANCE INGESTION (CITIZEN PORTAL)
# ==============================================================================
with tab_citizen:
    # 1. Modern Hero Header
    st.markdown("""
    <div class="hero-banner">
        <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
            <div>
                <span class="hero-badge">BMC F-North Ward Official</span>
                <div class="hero-title">JAN-MANAS (जन-मानस) Civic Portal</div>
                <div class="hero-subtitle">Brihanmumbai Municipal Corporation | GTB Nagar & Sion Koliwada Citizen Grievance Redressal</div>
            </div>
            <div class="helpline-box">
                <div style="font-size: 0.75rem; color: #E2E8F0; font-weight: 600; text-transform: uppercase;">24x7 BMC Disaster Helpline</div>
                <div style="font-size: 1.35rem; font-weight: 800; color: #FFFFFF;">📞 1916 / 022-2402</div>
            </div>
        </div>
    </div>
    """, unsafe_allow_html=True)

    # 2. Quick-fill Issue Buttons for 1-Click Testing
    st.markdown("#### ⚡ 1-Click Quick-Fill Real Grievance Scenarios")
    st.caption("Click any preset issue from GTB Nagar to immediately populate and test the real-time NLP analysis engine:")

    q_col1, q_col2, q_col3 = st.columns(3)
    q_col4, q_col5, q_col6 = st.columns(3)

    PRESETS = {
        "p1": {
            "title": "🚨 Open Manhole (Sardar Nagar)",
            "locality": "Sardar Nagar Sector 1-4",
            "category": "Water Supply & Sewage",
            "text": "Extremely dangerous open manhole without cover near Sardar Nagar Circle No. 2! It is a blind corner and two-wheelers could easily fall in. Immediate accident hazard!"
        },
        "p2": {
            "title": "🗑️ Garbage Heap (GTB Station)",
            "locality": "GTB Nagar Railway Station",
            "category": "Solid Waste Management",
            "text": "Huge garbage heap accumulated outside GTB Station East near the auto rickshaw stand. Rotting waste and foul stench making it impossible to walk or breathe!"
        },
        "p3": {
            "title": "⚡ Sparking Wire (Sion Koliwada)",
            "locality": "Sion Koliwada",
            "category": "Street Lighting & Public Safety",
            "text": "Electric wire hanging low from lamppost near Flank Road municipal school is sparking when touching tree branches. Serious electrocution risk for school children!"
        },
        "p4": {
            "title": "💧 Choked Drain & Dengue (Punjabi Colony)",
            "locality": "Punjabi Colony",
            "category": "Water Supply & Sewage",
            "text": "Open storm drain choked with plastic bottles near Punjabi Colony central park. Stagnant rainwater breeding swarms of mosquitoes. Dengue cases are rising rapidly!"
        },
        "p5": {
            "title": "🕳️ Crater Potholes (Sion Koliwada)",
            "locality": "Sion Koliwada",
            "category": "Roads & Infrastructure",
            "text": "Massive road cave-in and broken asphalt near Flank Road bus stop following pipe repair work. Major accident spot with vehicles constantly skidding."
        },
        "p6": {
            "title": "✨ Prompt Service (GTB Station)",
            "locality": "GTB Nagar Railway Station",
            "category": "Solid Waste Management",
            "text": "BMC solid waste collection truck arrived on schedule at GTB Station Road. Cleaners cleared the community bins thoroughly. Appreciate the prompt morning service!"
        }
    }

    with q_col1:
        if st.button(PRESETS["p1"]["title"], use_container_width=True):
            st.session_state["portal_locality"] = PRESETS["p1"]["locality"]
            st.session_state["portal_category"] = PRESETS["p1"]["category"]
            st.session_state["portal_text"] = PRESETS["p1"]["text"]
            st.rerun()
    with q_col2:
        if st.button(PRESETS["p2"]["title"], use_container_width=True):
            st.session_state["portal_locality"] = PRESETS["p2"]["locality"]
            st.session_state["portal_category"] = PRESETS["p2"]["category"]
            st.session_state["portal_text"] = PRESETS["p2"]["text"]
            st.rerun()
    with q_col3:
        if st.button(PRESETS["p3"]["title"], use_container_width=True):
            st.session_state["portal_locality"] = PRESETS["p3"]["locality"]
            st.session_state["portal_category"] = PRESETS["p3"]["category"]
            st.session_state["portal_text"] = PRESETS["p3"]["text"]
            st.rerun()
    with q_col4:
        if st.button(PRESETS["p4"]["title"], use_container_width=True):
            st.session_state["portal_locality"] = PRESETS["p4"]["locality"]
            st.session_state["portal_category"] = PRESETS["p4"]["category"]
            st.session_state["portal_text"] = PRESETS["p4"]["text"]
            st.rerun()
    with q_col5:
        if st.button(PRESETS["p5"]["title"], use_container_width=True):
            st.session_state["portal_locality"] = PRESETS["p5"]["locality"]
            st.session_state["portal_category"] = PRESETS["p5"]["category"]
            st.session_state["portal_text"] = PRESETS["p5"]["text"]
            st.rerun()
    with q_col6:
        if st.button(PRESETS["p6"]["title"], use_container_width=True):
            st.session_state["portal_locality"] = PRESETS["p6"]["locality"]
            st.session_state["portal_category"] = PRESETS["p6"]["category"]
            st.session_state["portal_text"] = PRESETS["p6"]["text"]
            st.rerun()

    st.markdown("---")

    # 3. Multi-Input Grievance Area
    st.markdown("#### 📝 Register Your Civic Grievance")

    default_loc = st.session_state.get("portal_locality", LOCALITY_OPTIONS[0])
    default_cat = st.session_state.get("portal_category", "🤖 Auto-Detect with AI (Recommended)")
    default_text = st.session_state.get("portal_text", "")

    loc_index = LOCALITY_OPTIONS.index(default_loc) if default_loc in LOCALITY_OPTIONS else 0
    cat_options = ["🤖 Auto-Detect with AI (Recommended)"] + VALID_DEPARTMENTS
    cat_index = cat_options.index(default_cat) if default_cat in cat_options else 0

    col_loc, col_cat = st.columns(2)
    with col_loc:
        selected_locality = st.selectbox(
            "📍 Locality / GTB Nagar Ward Sector",
            LOCALITY_OPTIONS,
            index=loc_index,
            help="Select the neighborhood or landmark nearest to the issue."
        )
    with col_cat:
        selected_category = st.selectbox(
            "🏢 Responsible Department",
            cat_options,
            index=cat_index,
            help="Choose 'Auto-Detect' to let the NLP classifier determine the BMC department."
        )

    complaint_input = st.text_area(
        "📄 Detailed Complaint Statement (Natural Language)",
        value=default_text,
        height=130,
        placeholder="Type or paste citizen grievance here. e.g.: Open manhole near Sardar Nagar Circle posing an immediate accident hazard...",
        key="portal_text_area"
    )

    # 4. Real-time Instant Preview Card
    active_text = complaint_input.strip()

    if active_text and len(active_text) >= 5:
        sent_result = analyze_civic_sentiment(active_text)
        pol_score = sent_result["sentiment_score"]
        sent_label = sent_result["sentiment_label"]
        emo_state = sent_result["emotional_state"]

        if selected_category == "🤖 Auto-Detect with AI (Recommended)":
            dept_result = department_classifier.classify(active_text)
            preview_dept = dept_result["department"]
            dept_conf = dept_result["confidence"]
        else:
            preview_dept = selected_category
            dept_conf = 1.0

        urg_result = calculate_urgency(active_text, sentiment_score=pol_score)
        preview_urgency = urg_result["urgency_level"]
        urg_score = urg_result["urgency_score"]
        detected_hazards = urg_result["detected_hazards"]
        urg_reason = urg_result["reasoning"]

        st.markdown("""
        <div class="preview-container">
            <div class="preview-header">
                <span>⚡ Live NLP Diagnostic & Assessment Preview</span>
            </div>
        """, unsafe_allow_html=True)

        prev_col1, prev_col2, prev_col3 = st.columns(3)

        with prev_col1:
            st.markdown("**1. Target BMC Department**")
            dept_icons = {
                "Solid Waste Management": "🗑️",
                "Roads & Infrastructure": "🚧",
                "Water Supply & Sewage": "🚰",
                "Street Lighting & Public Safety": "💡"
            }
            icon = dept_icons.get(preview_dept, "🏛️")
            st.markdown(f"### {icon} {preview_dept}")
            st.caption(f"AI Confidence: **{int(dept_conf * 100)}%**")

        with prev_col2:
            st.markdown("**2. Sentiment & Emotional State**")
            emo_badge_class = {
                "Frustrated": "badge-frustrated",
                "Moderate Concern": "badge-concern",
                "Neutral/Satisfied": "badge-satisfied"
            }.get(emo_state, "badge-concern")
            
            emo_emoji = {
                "Frustrated": "😡",
                "Moderate Concern": "⚠️",
                "Neutral/Satisfied": "🟢"
            }.get(emo_state, "😐")

            st.markdown(f"""
                <div style="margin: 8px 0;">
                    <span class="{emo_badge_class}">{emo_emoji} {emo_state.upper()}</span>
                </div>
            """, unsafe_allow_html=True)
            st.caption(f"Polarity Score: **{pol_score:+.2f}** ({sent_label})")

        with prev_col3:
            st.markdown("**3. Urgency Priority Assessment**")
            urg_class = {
                "High": "badge-high",
                "Medium": "badge-medium",
                "Low": "badge-low"
            }.get(preview_urgency, "badge-medium")

            urg_icon = {"High": "🚨", "Medium": "🟡", "Low": "🟢"}.get(preview_urgency, "📌")

            st.markdown(f"""
                <div style="margin: 8px 0;">
                    <span class="{urg_class}">{urg_icon} {preview_urgency.upper()} URGENCY</span>
                </div>
            """, unsafe_allow_html=True)
            st.caption(f"Danger Index: **{urg_score:.2f} / 1.00**")

        if detected_hazards:
            hazard_tags = " ".join([f"`🚨 {h}`" for h in detected_hazards])
            st.markdown(f"**Identified Critical Hazard Triggers:** {hazard_tags}")
        st.caption(f"**Municipal Routing Note:** {urg_reason}")

        st.markdown("</div>", unsafe_allow_html=True)

    else:
        st.info("💡 Type a complaint above or click one of the 1-Click Quick-Fill buttons to see the real-time NLP diagnostic preview.")

    # 5. Submit Button & Tracking Token Generation
    col_sub1, col_sub2 = st.columns([2, 1])
    with col_sub1:
        submit_btn = st.button("🚀 Submit Citizen Grievance to BMC F-North Ward", type="primary", use_container_width=True)

    if submit_btn:
        if not active_text or len(active_text) < 8:
            st.error("Please enter a detailed complaint description before submitting.")
        else:
            with st.spinner("Recording grievance and dispatching to BMC Ward Database..."):
                sent = analyze_civic_sentiment(active_text)
                final_score = sent["sentiment_score"]
                final_label = sent["sentiment_label"]

                if selected_category == "🤖 Auto-Detect with AI (Recommended)":
                    dept_res = department_classifier.classify(active_text)
                    final_dept = dept_res["department"]
                else:
                    final_dept = selected_category

                urg_res = calculate_urgency(active_text, sentiment_score=final_score)
                final_urgency = urg_res["urgency_level"]

                canonical_cluster = LOCALITY_TO_CLUSTER.get(selected_locality, selected_locality)

                new_id = db.insert_feedback(
                    raw_text=active_text,
                    location_cluster=canonical_cluster,
                    category=final_dept,
                    sentiment_score=final_score,
                    sentiment_label=final_label,
                    urgency_level=final_urgency,
                    status="Pending"
                )

                tracking_token = generate_tracking_token(new_id)

                sla_map = {
                    "High": "Emergency Dispatch within 4 Hours (Ward Quick Response Team)",
                    "Medium": "Inspection and Redressal within 24 Hours",
                    "Low": "Standard Municipal Redressal within 48-72 Hours"
                }

                st.markdown(f"""
                <div class="token-card">
                    <div style="display: flex; align-items: center; gap: 8px;">
                        <span style="font-size: 1.5rem;">✅</span>
                        <h3 style="color: #166534; margin: 0;">Grievance Successfully Registered with BMC F-North Ward!</h3>
                    </div>
                    <p style="color: #15803D; margin: 6px 0 10px 0;">Your civic report has been classified, prioritized, and queued in the ward management system.</p>
                    <div>Official Citizen Tracking Token:</div>
                    <div class="token-id">{tracking_token}</div>
                    <div style="font-size: 0.88rem; color: #374151; margin-top: 10px;">
                        • <strong>Assigned Department:</strong> {final_dept}<br>
                        • <strong>Locality:</strong> {selected_locality} ({canonical_cluster})<br>
                        • <strong>Priority Level:</strong> {final_urgency} Urgency<br>
                        • <strong>Target SLA:</strong> {sla_map.get(final_urgency)}<br>
                        • <strong>Status:</strong> Pending Ward Officer Inspection
                    </div>
                </div>
                """, unsafe_allow_html=True)
                st.balloons()


# ==============================================================================
# TAB 2: GTB NAGAR HOTSPOT MAP
# ==============================================================================
with tab_map:
    st.markdown("### 🗺️ BMC F-North Ward — GTB Nagar Hotspot Map")
    st.caption("Geospatial distribution of civic grievances and urgent municipal hazards across GTB Nagar and Sion Koliwada.")

    all_feedbacks = db.get_all_feedback(
        cluster=sidebar_cluster,
        category=sidebar_dept,
        urgency=sidebar_urgency,
        status=sidebar_status,
        search_query=sidebar_search
    )

    total_map_items = len(all_feedbacks)
    high_urgency_items = sum(1 for f in all_feedbacks if f["urgency_level"] == "High")
    resolved_map_items = sum(1 for f in all_feedbacks if f["status"] == "Resolved")
    
    avg_pol = (
        round(sum(f["sentiment_score"] for f in all_feedbacks) / total_map_items, 2)
        if total_map_items > 0 else 0.0
    )
    if avg_pol <= -0.40:
        sentiment_summary_label = "Frustrated"
    elif avg_pol < 0.05:
        sentiment_summary_label = "Moderate Concern"
    else:
        sentiment_summary_label = "Neutral/Satisfied"

    col_m1, col_m2, col_m3, col_m4 = st.columns(4)
    with col_m1:
        st.metric("Total Complaints Plotted", total_map_items, help="Count of complaints matching current filters")
    with col_m2:
        st.metric("🚨 Urgent Hazards", high_urgency_items, delta=f"{high_urgency_items} Critical Red Pins", delta_color="inverse")
    with col_m3:
        st.metric("Resolved Cases", resolved_map_items, delta=f"{round(resolved_map_items/max(1,total_map_items)*100)}% Complete")
    with col_m4:
        st.metric("Average Resolution Sentiment", f"{avg_pol:+.2f}", delta=sentiment_summary_label)

    st.markdown("---")

    st.markdown("""
    <div style="display: flex; gap: 20px; align-items: center; margin-bottom: 12px; flex-wrap: wrap;">
        <span style="font-weight: 700; font-size: 0.9rem; color: #1E293B;">Hotspot Map Legend:</span>
        <span style="display: flex; align-items: center; gap: 6px; font-size: 0.85rem;">
            <span style="width: 14px; height: 14px; background-color: #EF4444; border-radius: 50%; display: inline-block;"></span>
            <strong>High Urgency (Red):</strong> Immediate Hazards (Manholes, Broken Pipes, Sparking Wires, Flooding)
        </span>
        <span style="display: flex; align-items: center; gap: 6px; font-size: 0.85rem;">
            <span style="width: 14px; height: 14px; background-color: #F59E0B; border-radius: 50%; display: inline-block;"></span>
            <strong>Medium Urgency (Yellow):</strong> Civic Nuisances (Potholes, Dark Lanes, Low Water Pressure)
        </span>
        <span style="display: flex; align-items: center; gap: 6px; font-size: 0.85rem;">
            <span style="width: 14px; height: 14px; background-color: #10B981; border-radius: 50%; display: inline-block;"></span>
            <strong>Low / Resolved (Green):</strong> Routine Maintenance & Citizen Commendations
        </span>
    </div>
    """, unsafe_allow_html=True)

    if not all_feedbacks:
        st.warning("No complaints found matching the selected filters. Reset filters to see the full GTB Nagar map.")
    else:
        plot_records = []
        for item in all_feedbacks:
            lat, lon = get_item_coordinates(item["id"], item["location_cluster"])
            urg = item["urgency_level"]
            status = item["status"]

            if status == "Resolved":
                color = [16, 185, 129, 220]
                radius = 22
            elif urg == "High":
                color = [239, 68, 68, 220]
                radius = 35
            elif urg == "Medium":
                color = [245, 158, 11, 220]
                radius = 26
            else:
                color = [16, 185, 129, 220]
                radius = 22

            text_snippet = item["raw_text"]
            if len(text_snippet) > 80:
                text_snippet = text_snippet[:77] + "..."

            plot_records.append({
                "id": item["id"],
                "lat": lat,
                "lon": lon,
                "cluster": item["location_cluster"],
                "category": item["category"],
                "urgency": urg,
                "sentiment_label": item["sentiment_label"],
                "sentiment_score": f"{item['sentiment_score']:.2f}",
                "status": status,
                "text": text_snippet,
                "color": color,
                "radius": radius
            })

        plot_df = pd.DataFrame(plot_records)

        scatter_layer = pdk.Layer(
            "ScatterplotLayer",
            data=plot_df,
            get_position="[lon, lat]",
            get_color="color",
            get_radius="radius",
            radius_min_pixels=6,
            radius_max_pixels=25,
            pickable=True,
            auto_highlight=True,
        )

        view_state = pdk.ViewState(
            latitude=GTB_NAGAR_CENTER["lat"],
            longitude=GTB_NAGAR_CENTER["lon"],
            zoom=14.5,
            pitch=35,
            bearing=0
        )

        tooltip_config = {
            "html": """
                <div style="background-color: #0F172A; color: #FFFFFF; padding: 10px 14px; border-radius: 8px; font-family: sans-serif; font-size: 12px; max-width: 280px; box-shadow: 0 4px 12px rgba(0,0,0,0.3);">
                    <div style="font-size: 13px; font-weight: bold; margin-bottom: 4px; color: #38BDF8;">
                        #{id} | {cluster}
                    </div>
                    <div style="margin-bottom: 3px;">
                        <strong>Department:</strong> {category}
                    </div>
                    <div style="margin-bottom: 3px;">
                        <strong>Urgency:</strong> <span style="font-weight: bold;">{urgency}</span> | <strong>Status:</strong> {status}
                    </div>
                    <div style="margin-bottom: 6px;">
                        <strong>Sentiment:</strong> {sentiment_label} ({sentiment_score})
                    </div>
                    <div style="color: #CBD5E1; font-style: italic; border-top: 1px solid #334155; padding-top: 4px;">
                        "{text}"
                    </div>
                </div>
            """,
            "style": {"zIndex": "1000"}
        }

        deck = pdk.Deck(
            layers=[scatter_layer],
            initial_view_state=view_state,
            tooltip=tooltip_config,
            map_style="light"
        )

        st.pydeck_chart(deck, use_container_width=True)

        st.markdown("#### 🚨 Critical Unresolved Hazard Watchlist (BMC Quick Response)")
        high_unresolved = [f for f in all_feedbacks if f["urgency_level"] == "High" and f["status"] != "Resolved"]
        
        if high_unresolved:
            h_cols = st.columns(min(3, len(high_unresolved)))
            for i, item in enumerate(high_unresolved[:3]):
                with h_cols[i]:
                    st.error(f"**#{item['id']} — {item['location_cluster']}**")
                    st.write(f"🏢 *{item['category']}*")
                    st.caption(f'"{item["raw_text"]}"')
                    if st.button(f"Mark #{item['id']} In Progress", key=f"quick_prog_{item['id']}"):
                        db.update_status(item['id'], "In Progress")
                        st.success(f"Status updated for #{item['id']}!")
                        st.rerun()
        else:
            st.success("🎉 All high urgency hazards in the current view have been resolved!")


# ==============================================================================
# TAB 3: WARD OFFICER COMMAND DECK
# ==============================================================================
with tab_command:
    st.markdown("### 🛡️ BMC F-North Ward — Officer Command & Triage Deck")
    st.caption("Operational triage console for Ward Executive Engineers, Assistant Commissioners, and Field Technicians.")

    all_command_items = db.get_all_feedback()
    
    # 1. Visual Kanban / KPI Counters
    pending_count = sum(1 for f in all_command_items if f["status"] == "Pending")
    in_prog_count = sum(1 for f in all_command_items if f["status"] == "In Progress")
    resolved_count = sum(1 for f in all_command_items if f["status"] == "Resolved")
    active_high_count = sum(1 for f in all_command_items if f["urgency_level"] == "High" and f["status"] != "Resolved")

    k1, k2, k3, k4 = st.columns(4)
    with k1:
        st.markdown(f"""
        <div class="kanban-card" style="border-left-color: #F59E0B;">
            <div class="kanban-title">📥 Pending Review</div>
            <div class="kanban-count" style="color: #D97706;">{pending_count}</div>
            <div style="font-size: 0.78rem; color: #94A3B8; margin-top: 4px;">Awaiting field dispatch</div>
        </div>
        """, unsafe_allow_html=True)
    with k2:
        st.markdown(f"""
        <div class="kanban-card" style="border-left-color: #3B82F6;">
            <div class="kanban-title">🔍 Under Inspection</div>
            <div class="kanban-count" style="color: #2563EB;">{in_prog_count}</div>
            <div style="font-size: 0.78rem; color: #94A3B8; margin-top: 4px;">Field team on-site</div>
        </div>
        """, unsafe_allow_html=True)
    with k3:
        st.markdown(f"""
        <div class="kanban-card" style="border-left-color: #10B981;">
            <div class="kanban-title">✅ Resolved Cases</div>
            <div class="kanban-count" style="color: #059669;">{resolved_count}</div>
            <div style="font-size: 0.78rem; color: #94A3B8; margin-top: 4px;">Redressal complete</div>
        </div>
        """, unsafe_allow_html=True)
    with k4:
        st.markdown(f"""
        <div class="kanban-card" style="border-left-color: #EF4444;">
            <div class="kanban-title">🚨 Active High Hazards</div>
            <div class="kanban-count" style="color: #DC2626;">{active_high_count}</div>
            <div style="font-size: 0.78rem; color: #94A3B8; margin-top: 4px;">Immediate danger priority</div>
        </div>
        """, unsafe_allow_html=True)

    st.markdown("---")

    # 2. Priority Triage Table with Immediate Filtering
    st.markdown("#### 🚨 Priority Triage Console")
    
    t_f1, t_f2, t_f3, t_f4 = st.columns([1.5, 2, 2, 1.5])
    with t_f1:
        triage_urgency = st.selectbox("Triage Urgency", ["All", "High", "Medium", "Low"], index=0, key="triage_urg_filter")
    with t_f2:
        triage_dept = st.selectbox("Department", ["All"] + VALID_DEPARTMENTS, index=0, key="triage_dept_filter")
    with t_f3:
        triage_status = st.selectbox("Workflow State", ["All", "Pending", "In Progress", "Resolved"], index=0, key="triage_stat_filter")
    with t_f4:
        st.write("")
        st.write("")
        only_high_btn = st.checkbox("🔥 High Priority Only", value=False)

    if only_high_btn:
        triage_urgency = "High"

    triaged_feedbacks = db.get_all_feedback(
        cluster=None,
        category=None if triage_dept == "All" else triage_dept,
        urgency=None if triage_urgency == "All" else triage_urgency,
        status=None if triage_status == "All" else triage_status
    )

    if not triaged_feedbacks:
        st.info("No grievances match the selected command filters.")
    else:
        # Sort so High Urgency appears at the very top
        triaged_df = pd.DataFrame(triaged_feedbacks)
        urgency_rank = {"High": 0, "Medium": 1, "Low": 2}
        triaged_df["urgency_rank"] = triaged_df["urgency_level"].map(urgency_rank)
        triaged_df = triaged_df.sort_values(by=["urgency_rank", "id"], ascending=[True, False]).drop(columns=["urgency_rank"])

        # Display Triage Table
        st.dataframe(
            triaged_df[["id", "timestamp", "location_cluster", "category", "urgency_level", "sentiment_label", "sentiment_score", "status", "raw_text"]],
            column_config={
                "id": st.column_config.NumberColumn("ID", width="small"),
                "timestamp": st.column_config.TextColumn("Timestamp", width="medium"),
                "location_cluster": st.column_config.TextColumn("Locality", width="medium"),
                "category": st.column_config.TextColumn("Department", width="large"),
                "urgency_level": st.column_config.TextColumn("Urgency", width="small"),
                "sentiment_label": st.column_config.TextColumn("Sentiment", width="small"),
                "sentiment_score": st.column_config.NumberColumn("Score", format="%.2f", width="small"),
                "status": st.column_config.TextColumn("Status", width="small"),
                "raw_text": st.column_config.TextColumn("Citizen Statement", width="large"),
            },
            use_container_width=True,
            hide_index=True
        )

        # 3. CSV Export Button
        export_csv = triaged_df.to_csv(index=False).encode("utf-8")
        st.download_button(
            label="📥 1-Click Export Ward Records (CSV)",
            data=export_csv,
            file_name=f"BMC_F_North_Ward_Report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
            mime="text/csv",
            help="Download official CSV export for municipal archives and ward committee meetings."
        )

    st.markdown("---")

    # 4. Status Updater & WhatsApp Municipal Field Officer Dispatch
    st.markdown("#### 📲 Field Officer Dispatch & Status Workflow Controller")
    st.caption("Select a grievance to update resolution status or dispatch an auto-formatted WhatsApp alert directly to on-site municipal field staff.")

    cmd_col1, cmd_col2 = st.columns([1.2, 1.8])

    with cmd_col1:
        st.markdown("**1. Select & Update Grievance**")
        all_ids = [f["id"] for f in all_command_items]
        selected_cmd_id = st.selectbox(
            "Target Grievance ID",
            options=all_ids,
            format_func=lambda x: f"#{x} - {db.get_feedback_by_id(x)['urgency_level']} | {db.get_feedback_by_id(x)['category'][:20]}... ({db.get_feedback_by_id(x)['location_cluster']})",
            key="cmd_select_id"
        )

        target_item = db.get_feedback_by_id(selected_cmd_id)
        if target_item:
            current_st = target_item["status"]
            st_idx = VALID_STATUS.index(current_st) if current_st in VALID_STATUS else 0
            
            new_cmd_status = st.radio(
                "Change Workflow Status",
                VALID_STATUS,
                index=st_idx,
                horizontal=True
            )

            officer_name = st.text_input(
                "Field Officer / Junior Engineer Assigned",
                value="Junior Engineer - F-North Ward Quick Response Team"
            )

            if st.button("💾 Apply Status & Update Records", type="primary", use_container_width=True):
                db.update_status(selected_cmd_id, new_cmd_status)
                st.success(f"Grievance #{selected_cmd_id} status updated to '{new_cmd_status}'!")
                st.rerun()

    with cmd_col2:
        st.markdown("**2. Auto-Formatted WhatsApp Alert for Field Staff**")
        if target_item:
            t_token = generate_tracking_token(target_item["id"])
            t_urg = target_item["urgency_level"]
            t_dept = target_item["category"]
            t_loc = target_item["location_cluster"]
            t_time = target_item["timestamp"]
            t_text = target_item["raw_text"]

            sla_text = "4 Hours Emergency Response" if t_urg == "High" else "24 Hours Standard Redressal"

            # Auto-generated formatted WhatsApp text
            whatsapp_msg = (
                f"🚨 *BMC F-NORTH WARD EMERGENCY CIVIC DISPATCH* 🚨\n"
                f"━━━━━━━━━━━━━━━━━━━━━━\n"
                f"📌 *Tracking Token:* {t_token}\n"
                f"⚠️ *Priority Level:* {t_urg.upper()} URGENCY HAZARD\n"
                f"🏢 *Department:* {t_dept}\n"
                f"📍 *Locality:* {t_loc} (GTB Nagar)\n"
                f"⏰ *Reported At:* {t_time}\n"
                f"🎯 *Target SLA:* {sla_text}\n"
                f"━━━━━━━━━━━━━━━━━━━━━━\n"
                f"📝 *Citizen Statement:*\n"
                f"\"{t_text}\"\n"
                f"━━━━━━━━━━━━━━━━━━━━━━\n"
                f"👷 *Assigned Unit:* {officer_name}\n"
                f"⚠️ *Action Required:* Immediate site barricading, verification & corrective action.\n"
                f"— *Dispatched via BMC F-North Control Room*"
            )

            st.code(whatsapp_msg, language="markdown")

            encoded_msg = quote(whatsapp_msg)
            wa_url = f"https://api.whatsapp.com/send?text={encoded_msg}"
            
            st.markdown(f"""
            <a href="{wa_url}" target="_blank" style="text-decoration: none;">
                <button style="
                    background-color: #25D366;
                    color: white;
                    border: none;
                    border-radius: 8px;
                    padding: 10px 20px;
                    font-weight: 700;
                    font-size: 0.95rem;
                    cursor: pointer;
                    display: inline-flex;
                    align-items: center;
                    gap: 8px;
                    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                    width: 100%;
                    justify-content: center;
                ">
                    📲 Dispatch Alert via WhatsApp Web / Mobile
                </button>
            </a>
            """, unsafe_allow_html=True)


# ==============================================================================
# TAB 4: ACADEMIC XAI & ANALYTICS DESK (UNIVERSITY VIVA DEFENSE)
# ==============================================================================
with tab_xai:
    st.markdown("""
    <div class="academic-banner">
        <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">
            <div>
                <span style="background: rgba(255,255,255,0.2); padding: 3px 8px; border-radius: 4px; font-size: 0.75rem; font-weight: 700;">ACADEMIC EVALUATION DESK</span>
                <h2 style="color: white; margin: 6px 0 2px 0; font-size: 1.6rem; font-weight: 800;">Explainable AI (XAI) & Model Validation Desk</h2>
                <div style="color: #C7D2FE; font-size: 0.9rem;">Multi-Task Natural Language Processing, Feature Attribution & Empirical Governance Benchmarks</div>
            </div>
            <div style="background: rgba(255,255,255,0.15); padding: 8px 14px; border-radius: 8px; text-align: right;">
                <div style="font-size: 0.72rem; color: #E0E7FF; font-weight: 600;">EVALUATION CORPUS</div>
                <div style="font-size: 1.15rem; font-weight: 800; color: #FFFFFF;">N = 520 Grievances</div>
            </div>
        </div>
    </div>
    """, unsafe_allow_html=True)

    # 1. Static Model Validation Benchmark Card
    st.markdown("#### 🎖️ Empirical Validation Benchmarks (University Index)")
    st.caption("5-Fold Stratified Cross-Validation on BMC F-North Ward annotated civic corpus:")

    v_c1, v_c2, v_c3, v_c4 = st.columns(4)
    with v_c1:
        st.metric("Macro Precision", f"{ACADEMIC_VALIDATION_METRICS['macro_precision']}%", delta="Confidence Interval ±1.2%")
    with v_c2:
        st.metric("Macro Recall", f"{ACADEMIC_VALIDATION_METRICS['macro_recall']}%", delta="Sensitivity")
    with v_c3:
        st.metric("Macro F1-Score", f"{ACADEMIC_VALIDATION_METRICS['macro_f1']}%", delta="Harmonic Mean")
    with v_c4:
        st.metric("Overall Accuracy", f"{ACADEMIC_VALIDATION_METRICS['accuracy']}%", delta="Cohen's κ = 0.88")

    # Detailed Per-Department Performance Table
    with st.expander("📊 View Per-Department Precision-Recall-F1 Breakdown", expanded=False):
        academic_df = pd.DataFrame(ACADEMIC_VALIDATION_METRICS["department_breakdown"])
        st.table(academic_df.set_index("department"))
        st.caption("Validation Methodology: 5-Fold Stratified Cross-Validation, inter-annotator agreement Cohen's κ = 0.88 across BMC F-North Ward complaints.")

    st.markdown("---")

    # 2. Plotly Charts: Department Sentiment Polarity & Urgency Severity Donut
    st.markdown("#### 📈 Ward-Level Distribution Analytics")
    
    chart_col1, chart_col2 = st.columns(2)
    feedback_analytics_data = db.get_all_feedback()
    df_chart = pd.DataFrame(feedback_analytics_data)

    with chart_col1:
        st.markdown("**Sentiment Polarity Distribution across BMC Departments**")
        if not df_chart.empty:
            dept_sentiment = df_chart.groupby("category")["sentiment_score"].mean().reset_index()
            dept_sentiment.columns = ["Department", "Average Polarity"]
            
            # Color condition: red for negative polarity, green for positive
            colors = ["#EF4444" if val < 0 else "#10B981" for val in dept_sentiment["Average Polarity"]]

            fig_bar = px.bar(
                dept_sentiment,
                x="Department",
                y="Average Polarity",
                color="Average Polarity",
                color_continuous_scale=[(0, "#DC2626"), (0.5, "#FBBF24"), (1, "#059669")],
                range_y=[-1.0, 1.0],
                title="Average Citizen Sentiment Polarity by Department"
            )
            fig_bar.add_hline(y=0.0, line_dash="dash", line_color="#64748B", annotation_text="Neutral Line (0.00)")
            fig_bar.update_layout(
                xaxis_title="",
                yaxis_title="Mean Polarity Score (-1.0 to +1.0)",
                margin=dict(l=10, r=10, t=30, b=10),
                height=340
            )
            st.plotly_chart(fig_bar, use_container_width=True)

    with chart_col2:
        st.markdown("**Urgency Severity Donut Chart**")
        if not df_chart.empty:
            urg_dist = df_chart["urgency_level"].value_counts().reset_index()
            urg_dist.columns = ["Urgency", "Count"]

            urgency_color_map = {
                "High": "#EF4444",
                "Medium": "#F59E0B",
                "Low": "#10B981"
            }

            fig_donut = go.Figure(data=[go.Pie(
                labels=urg_dist["Urgency"],
                values=urg_dist["Count"],
                hole=0.55,
                marker=dict(colors=[urgency_color_map.get(u, "#94A3B8") for u in urg_dist["Urgency"]]),
                textinfo="label+percent+value",
                hoverinfo="label+percent+value"
            )])

            fig_donut.update_layout(
                title="Distribution of Civic Urgency Tiers",
                annotations=[dict(text=f"Total<br><b>{len(df_chart)}</b>", x=0.5, y=0.5, font_size=15, showarrow=False)],
                margin=dict(l=10, r=10, t=30, b=10),
                height=340
            )
            st.plotly_chart(fig_donut, use_container_width=True)

    st.markdown("---")

    # 3. Interactive Testing Sandbox: Custom Examiner Input & Real-time Algorithmic Breakdown
    st.markdown("#### 🔬 Interactive XAI Testing Sandbox (Viva Examiner Console)")
    st.caption("Type any custom phrase below or select a viva test case to inspect token-level feature attribution, lexicon matching, and classification confidence:")

    ex_c1, ex_c2, ex_c3, ex_c4 = st.columns(4)
    with ex_c1:
        if st.button("🧪 Test 1: Open Manhole Accident", use_container_width=True):
            st.session_state["xai_input"] = "Dangerous open manhole without cover near school poses immediate accident hazard!"
            st.rerun()
    with ex_c2:
        if st.button("🧪 Test 2: Choked Sewer & Dengue", use_container_width=True):
            st.session_state["xai_input"] = "Gutter overflowing with filthy water breeding mosquitoes causing malaria and dengue fever!"
            st.rerun()
    with ex_c3:
        if st.button("🧪 Test 3: Rotting Kachra Stench", use_container_width=True):
            st.session_state["xai_input"] = "Huge community dustbin overflowing with rotting garbage and unbearable foul stench outside station."
            st.rerun()
    with ex_c4:
        if st.button("🧪 Test 4: Commendation / Resolved", use_container_width=True):
            st.session_state["xai_input"] = "Appreciate the prompt and excellent service by BMC cleaners. Clean water restored!"
            st.rerun()

    sandbox_input = st.text_input(
        "Enter phrase for real-time algorithmic inspection:",
        value=st.session_state.get("xai_input", "Dangerous open manhole near Sardar Nagar Circle posing an immediate accident hazard!"),
        key="sandbox_text_input"
    )

    if sandbox_input.strip():
        # Execute XAI breakdown
        explanation = xai_engine.explain_full(sandbox_input)

        sb_col1, sb_col2 = st.columns(2)

        with sb_col1:
            st.markdown("##### 1. Token Attribution Weights (Feature Importance)")
            st.caption(f"Composite Polarity: **{explanation['sentiment']['final_polarity']:+.2f}** | Civic Modifier: **{explanation['sentiment']['civic_modifier']:+.2f}**")
            
            token_data = explanation["sentiment"]["token_contributions"]
            if token_data:
                token_df = pd.DataFrame(token_data)
                
                # Plotly horizontal bar chart for token weights
                token_colors = ["#EF4444" if w < 0 else "#10B981" for w in token_df["weight"]]
                fig_tokens = px.bar(
                    token_df,
                    x="weight",
                    y="token",
                    orientation="h",
                    color="weight",
                    color_continuous_scale=[(0, "#DC2626"), (0.5, "#FBBF24"), (1, "#059669")],
                    title="Token-Level Polarity Weights (Feature Importance)"
                )
                fig_tokens.update_layout(
                    xaxis_title="Weight Contribution",
                    yaxis_title="",
                    margin=dict(l=10, r=10, t=30, b=10),
                    height=240
                )
                st.plotly_chart(fig_tokens, use_container_width=True)

                st.dataframe(token_df, use_container_width=True, hide_index=True)
            else:
                st.info("No strong sentiment polarity tokens identified; classified as Neutral Baseline.")

        with sb_col2:
            st.markdown("##### 2. Classification Confidence & Multi-Class Distribution")
            dept_probs = explanation["department"]["department_probabilities"]
            pred_dept = explanation["department"]["predicted_department"]
            conf = explanation["department"]["confidence"]

            st.markdown(f"**Predicted Department:** `{pred_dept}` (**{int(conf * 100)}% Confidence**)")
            
            for dept, prob in dept_probs.items():
                st.write(f"• **{dept}:** {prob:.1f}%")
                st.progress(float(prob) / 100.0)

            # 3. Urgency Rule Execution Trace
            st.markdown("##### 3. Urgency Decision Logic Trace")
            urg_info = explanation["urgency"]
            st.markdown(f"**Evaluated Level:** `{urg_info['urgency_level']}` | **Score:** `{urg_info['urgency_score']:.2f}`")
            
            trace_df = pd.DataFrame(urg_info["trace"])
            st.dataframe(trace_df, use_container_width=True, hide_index=True)
