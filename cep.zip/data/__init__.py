"""JAN-MANAS starter data."""
from data.starter_dataset import STARTER_FEEDBACK_ITEMS, get_starter_dataset

__all__ = ["STARTER_FEEDBACK_ITEMS", "get_starter_dataset"]
