"""
Synthetic starter dataset for JAN-MANAS: Civic Sentiment & Urgency Analyzer.
Target Area: BMC F-North Ward (Guru Tegh Bahadur Nagar / GTB Nagar / Sion Koliwada).

Location clusters allowed:
- GTB Station
- Sardar Nagar
- Punjabi Colony
- Flank Road
"""

from typing import List, Dict, Any

STARTER_FEEDBACK_ITEMS: List[Dict[str, Any]] = [
    {
        "id": 1,
        "timestamp": "2026-10-12 08:30:15",
        "location_cluster": "GTB Station",
        "raw_text": "Huge garbage heap accumulated outside GTB Station East near the auto rickshaw stand. Rotting waste and foul stench making it impossible to walk or breathe!",
        "category": "Solid Waste Management",
        "sentiment_score": -0.78,
        "sentiment_label": "Negative",
        "urgency_level": "High",
        "status": "Pending"
    },
    {
        "id": 2,
        "timestamp": "2026-10-12 09:15:22",
        "location_cluster": "Sardar Nagar",
        "raw_text": "Extremely dangerous open manhole without cover near Sardar Nagar Circle No. 2! It is a blind corner and two-wheelers could easily fall in. Immediate accident hazard!",
        "category": "Water Supply & Sewage",
        "sentiment_score": -0.85,
        "sentiment_label": "Negative",
        "urgency_level": "High",
        "status": "In Progress"
    },
    {
        "id": 3,
        "timestamp": "2026-10-12 10:45:00",
        "location_cluster": "Flank Road",
        "raw_text": "Major broken pipeline on main Flank Road near junction. Clean drinking water is continuously leaking and flooding the road since yesterday morning.",
        "category": "Water Supply & Sewage",
        "sentiment_score": -0.52,
        "sentiment_label": "Negative",
        "urgency_level": "High",
        "status": "Pending"
    },
    {
        "id": 4,
        "timestamp": "2026-10-12 11:20:10",
        "location_cluster": "Punjabi Colony",
        "raw_text": "Streetlights in Punjabi Colony Lane 3 have been non-functional for past four days. The whole lane is pitch dark at night, making residents and women feel unsafe.",
        "category": "Street Lighting & Public Safety",
        "sentiment_score": -0.62,
        "sentiment_label": "Negative",
        "urgency_level": "Medium",
        "status": "Pending"
    },
    {
        "id": 5,
        "timestamp": "2026-10-12 12:05:40",
        "location_cluster": "Sardar Nagar",
        "raw_text": "Electric wire hanging low from lamppost near Sardar Nagar municipal school is sparking when it touches tree branches. Serious electrocution risk for passing schoolchildren!",
        "category": "Street Lighting & Public Safety",
        "sentiment_score": -0.89,
        "sentiment_label": "Negative",
        "urgency_level": "High",
        "status": "Pending"
    },
    {
        "id": 6,
        "timestamp": "2026-10-12 13:30:00",
        "location_cluster": "GTB Station",
        "raw_text": "Gutter overflowing onto the main approach pathway of GTB Nagar station platform. Black dirty sewage water and intense breeding ground for mosquitoes causing dengue fear.",
        "category": "Water Supply & Sewage",
        "sentiment_score": -0.82,
        "sentiment_label": "Negative",
        "urgency_level": "High",
        "status": "In Progress"
    },
    {
        "id": 7,
        "timestamp": "2026-10-12 14:10:18",
        "location_cluster": "Punjabi Colony",
        "raw_text": "Deep potholes on the connecting road between Punjabi Colony and GTB Gurdwara. Bikers are losing balance and suffering back pain. Needs urgent asphalt paver leveling.",
        "category": "Roads & Infrastructure",
        "sentiment_score": -0.58,
        "sentiment_label": "Negative",
        "urgency_level": "Medium",
        "status": "Pending"
    },
    {
        "id": 8,
        "timestamp": "2026-10-12 15:00:25",
        "location_cluster": "Flank Road",
        "raw_text": "BMC solid waste collection truck arrived on schedule at Flank Road today. Cleaners cleared the community bins thoroughly. Appreciate the prompt morning service.",
        "category": "Solid Waste Management",
        "sentiment_score": 0.72,
        "sentiment_label": "Positive",
        "urgency_level": "Low",
        "status": "Resolved"
    },
    {
        "id": 9,
        "timestamp": "2026-10-12 16:22:50",
        "location_cluster": "Sardar Nagar",
        "raw_text": "Water supply pressure has been very low in Sardar Nagar Building 12 for the last two days. Tap water comes out muddy during evening hours.",
        "category": "Water Supply & Sewage",
        "sentiment_score": -0.45,
        "sentiment_label": "Negative",
        "urgency_level": "Medium",
        "status": "Pending"
    },
    {
        "id": 10,
        "timestamp": "2026-10-12 17:05:12",
        "location_cluster": "GTB Station",
        "raw_text": "Flickering sodium vapor street lamp near GTB Station West pedestrian bridge. Light keeps blinking and causes discomfort during rush hours.",
        "category": "Street Lighting & Public Safety",
        "sentiment_score": -0.22,
        "sentiment_label": "Negative",
        "urgency_level": "Low",
        "status": "Pending"
    },
    {
        "id": 11,
        "timestamp": "2026-10-13 08:10:00",
        "location_cluster": "Punjabi Colony",
        "raw_text": "Construction debris and concrete rubble left unattended on footpath along Punjabi Colony main road for over a week, blocking pedestrian movement.",
        "category": "Roads & Infrastructure",
        "sentiment_score": -0.41,
        "sentiment_label": "Negative",
        "urgency_level": "Medium",
        "status": "Pending"
    },
    {
        "id": 12,
        "timestamp": "2026-10-13 09:30:45",
        "location_cluster": "Flank Road",
        "raw_text": "Massive road cave-in and broken asphalt near Flank Road bus stop following recent underground pipe repair. Major accident spot for BEST buses.",
        "category": "Roads & Infrastructure",
        "sentiment_score": -0.76,
        "sentiment_label": "Negative",
        "urgency_level": "High",
        "status": "In Progress"
    },
    {
        "id": 13,
        "timestamp": "2026-10-13 10:15:30",
        "location_cluster": "Sardar Nagar",
        "raw_text": "Community dustbins in Sardar Nagar Sector 3 are completely overflowing. Stray dogs and cows scattering plastic kachra across the residential lane.",
        "category": "Solid Waste Management",
        "sentiment_score": -0.65,
        "sentiment_label": "Negative",
        "urgency_level": "High",
        "status": "Pending"
    },
    {
        "id": 14,
        "timestamp": "2026-10-13 11:00:10",
        "location_cluster": "GTB Station",
        "raw_text": "New LED street lighting installed along GTB Station Road has made the walkway brightly illuminated and much safer for late night commuters. Good job F-North ward team!",
        "category": "Street Lighting & Public Safety",
        "sentiment_score": 0.81,
        "sentiment_label": "Positive",
        "urgency_level": "Low",
        "status": "Resolved"
    },
    {
        "id": 15,
        "timestamp": "2026-10-13 12:40:55",
        "location_cluster": "Punjabi Colony",
        "raw_text": "Open storm drain choked with plastic bottles near Punjabi Colony central park. Stagnant rainwater breeding swarms of mosquitoes. Dengue cases are rising rapidly in our colony.",
        "category": "Water Supply & Sewage",
        "sentiment_score": -0.79,
        "sentiment_label": "Negative",
        "urgency_level": "High",
        "status": "Pending"
    },
    {
        "id": 16,
        "timestamp": "2026-10-13 14:05:20",
        "location_cluster": "Flank Road",
        "raw_text": "Streetlight pole bent at an awkward angle after a tempo hit it on Flank Road. Exposed electric junction box open at ground level.",
        "category": "Street Lighting & Public Safety",
        "sentiment_score": -0.71,
        "sentiment_label": "Negative",
        "urgency_level": "High",
        "status": "Pending"
    },
    {
        "id": 17,
        "timestamp": "2026-10-13 15:15:42",
        "location_cluster": "Sardar Nagar",
        "raw_text": "Footpath paver blocks are missing and broken outside Sardar Nagar Post Office. Elderly citizens frequently trip and fall while walking.",
        "category": "Roads & Infrastructure",
        "sentiment_score": -0.56,
        "sentiment_label": "Negative",
        "urgency_level": "Medium",
        "status": "In Progress"
    },
    {
        "id": 18,
        "timestamp": "2026-10-13 16:50:00",
        "location_cluster": "GTB Station",
        "raw_text": "Fish and vegetable market vendors dumping rotten organic waste beside GTB Station skywalk stairs. Nauseating stench and flies infestation.",
        "category": "Solid Waste Management",
        "sentiment_score": -0.74,
        "sentiment_label": "Negative",
        "urgency_level": "High",
        "status": "Pending"
    },
    {
        "id": 19,
        "timestamp": "2026-10-13 17:35:15",
        "location_cluster": "Punjabi Colony",
        "raw_text": "The recently repaired water pipeline in Punjabi Colony Sector A is supplying crystal clear water with excellent pressure today. Thank you BMC maintenance department.",
        "category": "Water Supply & Sewage",
        "sentiment_score": 0.85,
        "sentiment_label": "Positive",
        "urgency_level": "Low",
        "status": "Resolved"
    },
    {
        "id": 20,
        "timestamp": "2026-10-14 07:45:30",
        "location_cluster": "Flank Road",
        "raw_text": "Illegal commercial dumping of construction rubble on Flank Road sidewalk. Pedestrians forced to walk on heavy traffic lane risking accidents.",
        "category": "Solid Waste Management",
        "sentiment_score": -0.68,
        "sentiment_label": "Negative",
        "urgency_level": "High",
        "status": "Pending"
    },
    {
        "id": 21,
        "timestamp": "2026-10-14 08:30:00",
        "location_cluster": "Sardar Nagar",
        "raw_text": "Routine desilting of roadside storm water drain carried out in Sardar Nagar Lane 1. Drain flow is smooth now.",
        "category": "Water Supply & Sewage",
        "sentiment_score": 0.42,
        "sentiment_label": "Positive",
        "urgency_level": "Low",
        "status": "Resolved"
    },
    {
        "id": 22,
        "timestamp": "2026-10-14 09:12:44",
        "location_cluster": "GTB Station",
        "raw_text": "Severe road depression right in front of GTB Nagar railway station ticket counter. Rainwater stagnates into a foul puddle every morning.",
        "category": "Roads & Infrastructure",
        "sentiment_score": -0.49,
        "sentiment_label": "Negative",
        "urgency_level": "Medium",
        "status": "Pending"
    },
    {
        "id": 23,
        "timestamp": "2026-10-14 09:55:10",
        "location_cluster": "Punjabi Colony",
        "raw_text": "Underground sewer line choked and backflowing near Punjabi Colony Community Hall. Sewage water seeping into ground floor compounds.",
        "category": "Water Supply & Sewage",
        "sentiment_score": -0.81,
        "sentiment_label": "Negative",
        "urgency_level": "High",
        "status": "Pending"
    },
    {
        "id": 24,
        "timestamp": "2026-10-14 10:20:18",
        "location_cluster": "Flank Road",
        "raw_text": "Three streetlights near Flank Road fire station have been repaired and restored. Lighting coverage is now adequate across the stretch.",
        "category": "Street Lighting & Public Safety",
        "sentiment_score": 0.68,
        "sentiment_label": "Positive",
        "urgency_level": "Low",
        "status": "Resolved"
    },
    {
        "id": 25,
        "timestamp": "2026-10-14 10:50:35",
        "location_cluster": "Sardar Nagar",
        "raw_text": "Public speed breaker near Sardar Nagar children's park has faded paint markings. Vehicles don't slow down, near-accident happened yesterday.",
        "category": "Roads & Infrastructure",
        "sentiment_score": -0.53,
        "sentiment_label": "Negative",
        "urgency_level": "High",
        "status": "Pending"
    }
]


def get_starter_dataset() -> List[Dict[str, Any]]:
    """Return a fresh copy of the 25 GTB Nagar starter feedback items."""
    import copy
    return copy.deepcopy(STARTER_FEEDBACK_ITEMS)
