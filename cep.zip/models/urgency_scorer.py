"""
Urgency Scorer for JAN-MANAS.
Inspects feedback text for critical municipal hazard keywords,
combining threat indicators and civic sentiment to assign
urgency levels: 'High', 'Medium', or 'Low'.
"""

import re
from typing import Dict, Any, List, Optional

# Hazard indicators that pose immediate public safety threats
CRITICAL_HAZARD_KEYWORDS = [
    # Life safety & physical hazard
    "manhole", "open manhole", "manhole without cover",
    "accident", "accident hazard", "near-accident", "blind corner",
    "sparking", "sparks", "electric", "electric wire", "live wire",
    "electrocution", "exposed cable", "open junction box", "short circuit",
    # Infrastructure disaster / collapse
    "broken pipeline", "pipe burst", "road cave-in", "cave-in", "crater",
    # Health epidemics / biohazards
    "overflowing", "overflowing drain", "choked sewer", "backflowing",
    "mosquitoes", "swarms of mosquitoes", "dengue", "malaria",
    "rotting waste", "flies infestation",
    # Vulnerable populations at risk
    "schoolchildren", "children's park", "senior citizen", "elderly"
]

MEDIUM_URGENCY_KEYWORDS = [
    "pothole", "potholes", "khadda", "stench", "foul smell",
    "stagnant", "flickering", "low pressure", "muddy water",
    "dustbins overflowing", "construction debris", "debris",
    "paver blocks", "pitch dark", "dark lane", "unattended",
    "back pain", "tripping", "blocking"
]

RESOLUTION_INDICATORS = [
    "resolved", "repaired", "cleared", "fixed", "thank you",
    "appreciate", "good job", "prompt service", "crystal clear",
    "smooth now", "restored", "well done"
]


class UrgencyScorer:
    """Calculates municipal priority and danger level from text and sentiment."""

    def __init__(
        self,
        critical_keywords: Optional[List[str]] = None,
        medium_keywords: Optional[List[str]] = None
    ):
        self.critical_keywords = critical_keywords or CRITICAL_HAZARD_KEYWORDS
        self.medium_keywords = medium_keywords or MEDIUM_URGENCY_KEYWORDS
        self.resolution_indicators = RESOLUTION_INDICATORS

    def _normalize_text(self, text: str) -> str:
        return text.lower().strip()

    def detect_hazards(self, text: str) -> List[str]:
        """Identify critical safety hazards mentioned in the text."""
        norm_text = self._normalize_text(text)
        detected = []

        for hazard in self.critical_keywords:
            if " " in hazard:
                if hazard in norm_text:
                    detected.append(hazard)
            else:
                pattern = rf"\b{re.escape(hazard)}\b"
                if re.search(pattern, norm_text):
                    detected.append(hazard)

        return list(dict.fromkeys(detected))  # remove duplicates preserving order

    def score(self, text: str, sentiment_score: Optional[float] = None) -> Dict[str, Any]:
        """
        Evaluate urgency level: 'High', 'Medium', or 'Low'.

        Args:
            text: Civic feedback complaint or comment.
            sentiment_score: Optional sentiment polarity [-1.0, 1.0].
        """
        if not text or not text.strip():
            return {
                "urgency_level": "Low",
                "urgency_score": 0.1,
                "detected_hazards": [],
                "reasoning": "No text content provided."
            }

        norm_text = self._normalize_text(text)
        detected_hazards = self.detect_hazards(text)

        # Detect resolution / appreciation indicators
        is_positive_or_resolved = False
        for res_term in self.resolution_indicators:
            if res_term in norm_text:
                is_positive_or_resolved = True
                break

        # Check medium severity terms
        detected_medium = []
        for term in self.medium_keywords:
            if " " in term:
                if term in norm_text:
                    detected_medium.append(term)
            else:
                pattern = rf"\b{re.escape(term)}\b"
                if re.search(pattern, norm_text):
                    detected_medium.append(term)
        detected_medium = list(dict.fromkeys(detected_medium))

        # Base score computation
        urgency_score = 0.2
        reasons = []

        # If it's a positive/resolved message without ongoing danger
        if is_positive_or_resolved and (sentiment_score is not None and sentiment_score > 0.3):
            urgency_level = "Low"
            urgency_score = 0.1
            reasons.append("Appreciative or resolved feedback; routine logging only.")
            return {
                "urgency_level": urgency_level,
                "urgency_score": urgency_score,
                "detected_hazards": [],
                "reasoning": "; ".join(reasons)
            }

        # Critical hazard presence
        if len(detected_hazards) > 0:
            urgency_score += 0.5 + (min(3, len(detected_hazards)) * 0.1)
            reasons.append(f"Critical safety triggers detected: {', '.join(detected_hazards)}")

        # Medium urgency terms
        if len(detected_medium) > 0:
            urgency_score += min(0.3, len(detected_medium) * 0.08)
            reasons.append(f"Civic nuisance factors: {', '.join(detected_medium[:3])}")

        # Sentiment penalty (strong citizen frustration amplifies urgency)
        if sentiment_score is not None:
            if sentiment_score <= -0.6:
                urgency_score += 0.15
                reasons.append(f"Acute citizen distress (sentiment: {sentiment_score})")
            elif sentiment_score <= -0.3:
                urgency_score += 0.08

        # Cap score between 0.0 and 1.0
        urgency_score = round(min(1.0, max(0.0, urgency_score)), 2)

        # Final level assignment
        if len(detected_hazards) > 0 or urgency_score >= 0.65:
            urgency_level = "High"
        elif len(detected_medium) > 0 or urgency_score >= 0.40:
            urgency_level = "Medium"
        else:
            urgency_level = "Low"
            if not reasons:
                reasons.append("Routine maintenance or low-impact civic inquiry.")

        return {
            "urgency_level": urgency_level,
            "urgency_score": urgency_score,
            "detected_hazards": detected_hazards,
            "reasoning": "; ".join(reasons)
        }


# Module level singleton instance
urgency_scorer = UrgencyScorer()


def calculate_urgency(text: str, sentiment_score: Optional[float] = None) -> Dict[str, Any]:
    """Convenience helper for calculating urgency level and hazards."""
    return urgency_scorer.score(text, sentiment_score)
