"""
Rule-based Department Classifier for JAN-MANAS.
Classifies citizen grievances into 4 BMC municipal departments:
1. Solid Waste Management (SWM)
2. Roads & Infrastructure
3. Water Supply & Sewage
4. Street Lighting & Public Safety
"""

import re
from typing import Dict, Any, List, Tuple, Optional

# Comprehensive municipal keyword and phrase taxonomy
DEPARTMENT_TAXONOMY: Dict[str, Dict[str, Any]] = {
    "Solid Waste Management": {
        "phrases": [
            "garbage heap", "solid waste", "rotting waste", "foul stench", "unattended garbage",
            "overflowing bin", "community dustbin", "dustbins overflowing", "collection truck",
            "dead animal", "stray dogs and cows", "plastic kachra", "organic waste",
            "fish market vendors", "flies infestation", "illegal dumping", "dumping yard",
            "cleaners cleared", "sweeping staff", "safai karamchari", "kachra dumper"
        ],
        "keywords": [
            "garbage", "kachra", "trash", "waste", "dustbin", "dustbins", "bin", "bins",
            "dumper", "dumping", "dump", "rotting", "stench", "stinking", "filth", "filthy",
            "litter", "littering", "plastic", "rubbish", "refuse", "sanitation", "safai",
            "sweeper", "sweeping", "carcass", "muck", "stink"
        ]
    },
    "Roads & Infrastructure": {
        "phrases": [
            "deep potholes", "road broken", "broken asphalt", "paver blocks", "road cave-in",
            "cave-in", "crater on road", "speed breaker", "speed bump", "traffic island",
            "construction debris", "footpath paver", "road depression", "concrete rubble",
            "road repair", "unattended on footpath", "faded paint markings", "blind corner",
            "pothole repair", "pedestrian pathway", "zebra crossing", "divider broken"
        ],
        "keywords": [
            "pothole", "potholes", "khadda", "khadde", "road", "roads", "footpath", "footpaths",
            "pavement", "sidewalk", "paver", "pavers", "asphalt", "bitumen", "tar", "divider",
            "crater", "caved", "rubble", "skid", "skidding", "curb", "median", "bridge",
            "flyover", "patchwork", "depression", "leveling"
        ]
    },
    "Water Supply & Sewage": {
        "phrases": [
            "broken pipeline", "water pipeline", "drinking water", "tap water", "water supply",
            "water pressure", "low pressure", "muddy water", "dirty water", "contaminated water",
            "open manhole", "manhole cover", "overflowing drain", "choked drain", "storm drain",
            "sewage water", "sewer line", "backflow", "backflowing", "pipe burst", "pipe leak",
            "water leakage", "mosquito breeding", "swarms of mosquitoes", "dengue cases",
            "stagnant rainwater", "desilting of roadside", "drain flow", "gutter overflowing",
            "open gutter", "nullah", "nalas"
        ],
        "keywords": [
            "pipeline", "pipe", "pipes", "leak", "leaking", "leakage", "burst", "water",
            "sewer", "sewage", "gutter", "gutters", "drain", "drains", "drainage", "manhole",
            "manholes", "nullah", "nala", "nalas", "chamber", "desilting", "stagnant",
            "mosquito", "mosquitoes", "dengue", "malaria", "backflow", "choked", "clogged",
            "seeping", "contamination", "sludge"
        ]
    },
    "Street Lighting & Public Safety": {
        "phrases": [
            "street lighting", "street light", "street lights", "street lamp", "street lamps",
            "sodium vapor", "led street", "pitch dark", "dark lane", "dark road", "exposed electric",
            "electric wire", "hanging low", "live wire", "open junction box", "sparking",
            "short circuit", "electrocution risk", "flickering light", "blinking light",
            "lamppost", "lamp post", "electric pole", "bent pole", "high mast", "no light",
            "non-functional", "women feel unsafe", "unsafe at night", "electric shock"
        ],
        "keywords": [
            "streetlight", "streetlights", "light", "lights", "lighting", "lamp", "lamps",
            "lamppost", "pole", "wire", "wires", "cable", "cables", "sparking", "sparks",
            "electric", "electrical", "electrocution", "dark", "darkness", "pitch-dark",
            "flickering", "bulb", "bulbs", "short-circuit", "unsafe", "shock", "junction-box",
            "illumination", "illuminated"
        ]
    }
}


class DepartmentClassifier:
    """Rule-based and keyword dictionary classifier for civic feedback."""

    def __init__(self, taxonomy: Optional[Dict[str, Dict[str, Any]]] = None):
        self.taxonomy = taxonomy or DEPARTMENT_TAXONOMY

    def _normalize_text(self, text: str) -> str:
        """Clean and normalize text for robust token and phrase matching."""
        return text.lower().strip()

    def classify(self, text: str) -> Dict[str, Any]:
        """
        Classify input civic complaint text into the most probable department.

        Returns:
            Dict containing:
            - 'department': Best matching department name
            - 'confidence': Confidence score [0.0, 1.0]
            - 'scores': Raw match scores for all 4 departments
            - 'matched_terms': Details of matched phrases and keywords
        """
        if not text or not text.strip():
            return {
                "department": "Roads & Infrastructure",
                "confidence": 0.0,
                "scores": {dept: 0.0 for dept in self.taxonomy},
                "matched_terms": {dept: [] for dept in self.taxonomy}
            }

        norm_text = self._normalize_text(text)
        words = set(re.findall(r"\b[a-z0-9_-]+\b", norm_text))

        scores: Dict[str, float] = {dept: 0.0 for dept in self.taxonomy}
        matched_terms: Dict[str, List[str]] = {dept: [] for dept in self.taxonomy}

        # Multi-word phrase matching receives higher weight (3.0 pts per phrase)
        for dept, data in self.taxonomy.items():
            for phrase in data.get("phrases", []):
                if phrase in norm_text:
                    scores[dept] += 3.5
                    matched_terms[dept].append(f"[phrase] {phrase}")

            # Single word keyword matching (1.0 pt per keyword)
            for kw in data.get("keywords", []):
                if kw in words and not any(kw in term for term in matched_terms[dept]):
                    scores[dept] += 1.0
                    matched_terms[dept].append(f"[word] {kw}")

        # Determine winner
        best_dept = max(scores, key=lambda k: scores[k])
        max_score = scores[best_dept]
        total_score = sum(scores.values())

        if total_score > 0:
            confidence = round(min(1.0, max_score / (total_score + 1.0)), 2)
        else:
            # Fallback default if completely unclassifiable
            best_dept = "Solid Waste Management"
            confidence = 0.25

        return {
            "department": best_dept,
            "confidence": confidence,
            "scores": scores,
            "matched_terms": matched_terms
        }


# Module level singleton instance
department_classifier = DepartmentClassifier()


def classify_department(text: str) -> str:
    """Convenience helper returning just the department name."""
    result = department_classifier.classify(text)
    return result["department"]
