"""
Civic Sentiment Engine for JAN-MANAS.
Computes sentiment polarity (-1.0 to +1.0) and translates it into
civic emotional states ('Frustrated', 'Moderate Concern', 'Neutral/Satisfied')
and standard sentiment labels ('Positive', 'Neutral', 'Negative').
"""

import re
from typing import Dict, Any, Optional

# Civic lexicon weights for localized civic feedback enhancement
CIVIC_EMOTIONAL_BOOSTERS = {
    # High negative / frustration indicators
    "pathetic": -0.6,
    "disgusting": -0.65,
    "unbearable": -0.7,
    "stench": -0.5,
    "stinking": -0.5,
    "filthy": -0.55,
    "horrible": -0.6,
    "terrible": -0.6,
    "danger": -0.5,
    "dangerous": -0.55,
    "hazardous": -0.6,
    "accident": -0.5,
    "choked": -0.4,
    "overflowing": -0.4,
    "backflowing": -0.5,
    "rotting": -0.5,
    "inaction": -0.45,
    "harassment": -0.6,
    "nuisance": -0.4,
    "mosquitoes": -0.35,
    "dengue": -0.5,
    "malaria": -0.5,
    "potholes": -0.35,
    "broken": -0.35,
    "sparking": -0.5,
    "electrocution": -0.7,
    "falling": -0.3,
    "tripped": -0.35,
    # Positive / satisfaction indicators
    "prompt": 0.5,
    "promptly": 0.55,
    "cleared": 0.45,
    "clean": 0.45,
    "cleanliness": 0.5,
    "repaired": 0.5,
    "fixed": 0.5,
    "restored": 0.5,
    "excellent": 0.7,
    "good job": 0.65,
    "appreciate": 0.6,
    "appreciation": 0.6,
    "thank you": 0.6,
    "thanks": 0.5,
    "smooth": 0.4,
    "well done": 0.65,
    "brightly": 0.4,
    "illuminated": 0.4,
    "crystal clear": 0.6
}


class SentimentEngine:
    """Civic sentiment and emotional state analyzer."""

    def __init__(self, preferred_engine: str = "vader"):
        """
        Args:
            preferred_engine: 'vader' (NLTK VADER) or 'textblob'
        """
        self.preferred_engine = preferred_engine
        self.vader_analyzer = None
        self.textblob_available = False

        self._init_vader()
        self._init_textblob()

    def _init_vader(self) -> None:
        """Initialize NLTK VADER with safe fallback."""
        try:
            import nltk
            try:
                from nltk.sentiment.vader import SentimentIntensityAnalyzer
                self.vader_analyzer = SentimentIntensityAnalyzer()
            except LookupError:
                # Try downloading vader_lexicon
                nltk.download("vader_lexicon", quiet=True)
                from nltk.sentiment.vader import SentimentIntensityAnalyzer
                self.vader_analyzer = SentimentIntensityAnalyzer()
        except Exception:
            self.vader_analyzer = None

    def _init_textblob(self) -> None:
        """Check TextBlob availability."""
        try:
            from textblob import TextBlob
            self.textblob_available = True
        except ImportError:
            self.textblob_available = False

    def _calculate_civic_modifier(self, text: str) -> float:
        """
        Check for civic-specific keywords to adjust raw NLP scores
        to reflect municipal urgency and citizen sentiment accurately.
        """
        text_lower = text.lower()
        words = re.findall(r"\b[a-z0-9_-]+\b", text_lower)
        modifier = 0.0
        matches = 0

        # Multi-word phrase matches first
        for phrase, delta in CIVIC_EMOTIONAL_BOOSTERS.items():
            if " " in phrase and phrase in text_lower:
                modifier += delta
                matches += 1

        for word in words:
            if word in CIVIC_EMOTIONAL_BOOSTERS and " " not in word:
                modifier += CIVIC_EMOTIONAL_BOOSTERS[word]
                matches += 1

        if matches > 0:
            return modifier / (1.0 + (matches * 0.4))
        return 0.0

    def analyze_vader(self, text: str) -> float:
        """Compute compound polarity using NLTK VADER."""
        if self.vader_analyzer:
            scores = self.vader_analyzer.polarity_scores(text)
            return float(scores["compound"])
        raise RuntimeError("VADER analyzer not available.")

    def analyze_textblob(self, text: str) -> float:
        """Compute polarity using TextBlob."""
        if self.textblob_available:
            from textblob import TextBlob
            blob = TextBlob(text)
            return float(blob.sentiment.polarity)
        raise RuntimeError("TextBlob not available.")

    def analyze_lexicon_fallback(self, text: str) -> float:
        """Pure Python fallback sentiment score when external models fail."""
        text_lower = text.lower()
        score = 0.0
        words = re.findall(r"\b[a-z0-9_-]+\b", text_lower)
        if not words:
            return 0.0

        for word in words:
            if word in CIVIC_EMOTIONAL_BOOSTERS:
                score += CIVIC_EMOTIONAL_BOOSTERS[word]

        # Bound score between -1.0 and 1.0
        clamped = max(-1.0, min(1.0, score / max(1, len(words) * 0.2)))
        return round(clamped, 2)

    def compute_polarity(self, text: str) -> float:
        """
        Calculate unified polarity score in range [-1.0, +1.0].
        Combines primary NLP engine (VADER or TextBlob) with civic emotional tuning.
        """
        if not text or not text.strip():
            return 0.0

        base_score = 0.0
        engine_used = None

        if self.preferred_engine == "vader":
            try:
                base_score = self.analyze_vader(text)
                engine_used = "vader"
            except Exception:
                try:
                    base_score = self.analyze_textblob(text)
                    engine_used = "textblob"
                except Exception:
                    base_score = self.analyze_lexicon_fallback(text)
                    engine_used = "lexicon_fallback"
        else:
            try:
                base_score = self.analyze_textblob(text)
                engine_used = "textblob"
            except Exception:
                try:
                    base_score = self.analyze_vader(text)
                    engine_used = "vader"
                except Exception:
                    base_score = self.analyze_lexicon_fallback(text)
                    engine_used = "lexicon_fallback"

        # Apply civic emotional modifier for civic context realism
        modifier = self._calculate_civic_modifier(text)
        # Weighted combination: 70% NLP engine + 30% civic contextual modifier
        final_score = (0.7 * base_score) + (0.3 * modifier)

        # Ensure strict bounds [-1.0, +1.0]
        final_score = max(-1.0, min(1.0, final_score))
        return round(final_score, 2)

    def map_sentiment_label(self, score: float) -> str:
        """Map numerical polarity to Positive, Neutral, Negative."""
        if score >= 0.05:
            return "Positive"
        elif score <= -0.05:
            return "Negative"
        else:
            return "Neutral"

    def map_emotional_state(self, score: float, text: str = "") -> str:
        """
        Map polarity score into civic emotional states:
        - 'Frustrated': intense distress, acute dissatisfaction, persistent grievance (score <= -0.40).
        - 'Moderate Concern': noticeable annoyance, pending complaints, civic risk (-0.40 < score < 0.05).
        - 'Neutral/Satisfied': balanced inquiries, informational updates, or resolved appreciation (score >= 0.05).
        """
        if score <= -0.40:
            return "Frustrated"
        elif -0.40 < score < 0.05:
            return "Moderate Concern"
        else:
            return "Neutral/Satisfied"

    def analyze(self, text: str) -> Dict[str, Any]:
        """
        Full sentiment analysis pipeline returning score, label, and civic emotional state.
        """
        polarity = self.compute_polarity(text)
        sentiment_label = self.map_sentiment_label(polarity)
        emotional_state = self.map_emotional_state(polarity, text)

        return {
            "sentiment_score": polarity,
            "sentiment_label": sentiment_label,
            "emotional_state": emotional_state,
            "raw_text": text
        }


# Module level singleton instance
sentiment_engine = SentimentEngine()


def analyze_civic_sentiment(text: str) -> Dict[str, Any]:
    """Convenience helper function for sentiment analysis."""
    return sentiment_engine.analyze(text)
