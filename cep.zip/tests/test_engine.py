"""
Comprehensive test suite for JAN-MANAS core data structure and NLP processing engine.
"""

import os
import unittest
import tempfile
from utils.db_manager import DatabaseManager, CivicFeedback
from models.sentiment_engine import SentimentEngine, analyze_civic_sentiment
from models.department_classifier import DepartmentClassifier, classify_department
from models.urgency_scorer import UrgencyScorer, calculate_urgency
from data.starter_dataset import get_starter_dataset, STARTER_FEEDBACK_ITEMS


class TestJANMANAS(unittest.TestCase):
    def setUp(self):
        # Use a temporary SQLite database for test isolation
        self.temp_db = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
        self.temp_db_path = self.temp_db.name
        self.temp_db.close()
        self.db = DatabaseManager(self.temp_db_path)

    def tearDown(self):
        try:
            if os.path.exists(self.temp_db_path):
                os.remove(self.temp_db_path)
        except OSError:
            pass

    # ---------------------------------------------------------
    # 1. Database Manager Tests
    # ---------------------------------------------------------
    def test_database_initialization(self):
        """Verify database tables and indexes exist and initial count is 0."""
        self.assertEqual(self.db.get_count(), 0)

    def test_insert_and_retrieve_feedback(self):
        """Test inserting a single record and retrieving it."""
        rec_id = self.db.insert_feedback(
            raw_text="Open manhole near Sardar Nagar Circle No. 2! Immediate accident hazard!",
            location_cluster="Sardar Nagar",
            category="Water Supply & Sewage",
            sentiment_score=-0.85,
            sentiment_label="Negative",
            urgency_level="High",
            status="Pending"
        )
        self.assertIsInstance(rec_id, int)
        self.assertGreater(rec_id, 0)

        item = self.db.get_feedback_by_id(rec_id)
        self.assertIsNotNone(item)
        self.assertEqual(item["location_cluster"], "Sardar Nagar")
        self.assertEqual(item["category"], "Water Supply & Sewage")
        self.assertEqual(item["urgency_level"], "High")
        self.assertEqual(item["status"], "Pending")
        self.assertAlmostEqual(item["sentiment_score"], -0.85, places=2)

    def test_update_status(self):
        """Test status workflow transitions: Pending -> In Progress -> Resolved."""
        rec_id = self.db.insert_feedback(
            raw_text="Garbage heap outside GTB Station",
            location_cluster="GTB Station",
            category="Solid Waste Management",
            sentiment_score=-0.7,
            sentiment_label="Negative",
            urgency_level="High",
            status="Pending"
        )
        # Transition to In Progress
        success = self.db.update_status(rec_id, "In Progress")
        self.assertTrue(success)
        self.assertEqual(self.db.get_feedback_by_id(rec_id)["status"], "In Progress")

        # Transition to Resolved
        success = self.db.update_status(rec_id, "Resolved")
        self.assertTrue(success)
        self.assertEqual(self.db.get_feedback_by_id(rec_id)["status"], "Resolved")

        # Invalid status should raise ValueError
        with self.assertRaises(ValueError):
            self.db.update_status(rec_id, "InvalidStatus")

    def test_pre_seed_database_if_empty(self):
        """Test pre-seeding the 25 starter GTB Nagar items into empty database."""
        self.assertEqual(self.db.get_count(), 0)
        seeded = self.db.seed_database_if_empty()
        self.assertEqual(seeded, 25)
        self.assertEqual(self.db.get_count(), 25)

        # Calling again should not duplicate
        second_call = self.db.seed_database_if_empty()
        self.assertEqual(second_call, 0)
        self.assertEqual(self.db.get_count(), 25)

    def test_feedback_filtering_and_analytics(self):
        """Test cluster/department/urgency filtering and executive analytics."""
        self.db.seed_database_if_empty()

        # Filter by cluster
        gtb_items = self.db.get_all_feedback(cluster="GTB Station")
        self.assertGreater(len(gtb_items), 0)
        for it in gtb_items:
            self.assertEqual(it["location_cluster"], "GTB Station")

        # Filter by urgency
        high_items = self.db.get_all_feedback(urgency="High")
        self.assertGreater(len(high_items), 0)
        for it in high_items:
            self.assertEqual(it["urgency_level"], "High")

        # Filter by department
        swm_items = self.db.get_all_feedback(category="Solid Waste Management")
        self.assertGreater(len(swm_items), 0)
        for it in swm_items:
            self.assertEqual(it["category"], "Solid Waste Management")

        # Analytics summary
        analytics = self.db.get_analytics_summary()
        self.assertEqual(analytics["total_feedbacks"], 25)
        self.assertIn("High", analytics["urgency_distribution"])
        self.assertIn("Solid Waste Management", analytics["category_distribution"])
        self.assertIn("GTB Station", analytics["cluster_distribution"])

    # ---------------------------------------------------------
    # 2. Sentiment Engine Tests
    # ---------------------------------------------------------
    def test_sentiment_vader_and_states(self):
        """Verify polarity computation and mapping into civic emotional states."""
        engine = SentimentEngine()

        # Frustrated test case
        frustrated_text = "Horrible and disgusting! Rotting garbage heap outside GTB station is unbearable stench."
        res_frustrated = engine.analyze(frustrated_text)
        self.assertLess(res_frustrated["sentiment_score"], -0.3)
        self.assertEqual(res_frustrated["sentiment_label"], "Negative")
        self.assertEqual(res_frustrated["emotional_state"], "Frustrated")

        # Moderate concern test case
        concern_text = "Construction debris left on footpath along Punjabi Colony main road, blocking pedestrian movement."
        res_concern = engine.analyze(concern_text)
        self.assertLess(res_concern["sentiment_score"], 0.05)
        self.assertEqual(res_concern["emotional_state"], "Moderate Concern")

        # Satisfied test case
        satisfied_text = "Thank you BMC! Cleaners arrived promptly and did an excellent job clearing the debris."
        res_satisfied = engine.analyze(satisfied_text)
        self.assertGreater(res_satisfied["sentiment_score"], 0.3)
        self.assertEqual(res_satisfied["sentiment_label"], "Positive")
        self.assertEqual(res_satisfied["emotional_state"], "Neutral/Satisfied")

    def test_sentiment_polarity_bounds(self):
        """Ensure sentiment polarity is strictly bounded in [-1.0, 1.0]."""
        texts = [
            "",
            "Normal street",
            "Extremely terrible worst accident danger electrocution!",
            "Superb fantastic wonderful brilliant perfect prompt!"
        ]
        for t in texts:
            score = analyze_civic_sentiment(t)["sentiment_score"]
            self.assertGreaterEqual(score, -1.0)
            self.assertLessEqual(score, 1.0)

    # ---------------------------------------------------------
    # 3. Department Classifier Tests
    # ---------------------------------------------------------
    def test_department_classification_accuracy(self):
        """Verify keyword and phrase matching across the 4 BMC departments."""
        classifier = DepartmentClassifier()

        cases = [
            (
                "Huge overflowing garbage bin and rotting kachra on roadside",
                "Solid Waste Management"
            ),
            (
                "Deep potholes and broken paver blocks causing two-wheelers to skid",
                "Roads & Infrastructure"
            ),
            (
                "Water pipeline burst and overflowing sewer drain with dirty tap water",
                "Water Supply & Sewage"
            ),
            (
                "Flickering street light and exposed sparking electric wire from pole",
                "Street Lighting & Public Safety"
            )
        ]

        for text, expected_dept in cases:
            res = classifier.classify(text)
            self.assertEqual(res["department"], expected_dept, f"Failed for text: '{text}'")
            self.assertGreater(res["confidence"], 0.3)

    # ---------------------------------------------------------
    # 4. Urgency Scorer Tests
    # ---------------------------------------------------------
    def test_critical_hazards_flag_high_urgency(self):
        """Ensure critical hazard keywords trigger High Urgency."""
        scorer = UrgencyScorer()

        hazard_cases = [
            ("Open manhole without cover on main road", "manhole"),
            ("Two-wheelers met with severe accident near blind turn", "accident"),
            ("Drain overflowing and swarms of mosquitoes causing dengue", "overflowing"),
            ("Sparking live electric wire hanging near school", "sparking"),
            ("Broken pipeline leaking clean drinking water everywhere", "broken pipeline")
        ]

        for text, expected_hazard in hazard_cases:
            res = scorer.score(text, sentiment_score=-0.7)
            self.assertEqual(res["urgency_level"], "High", f"Failed urgency for: '{text}'")
            self.assertIn(expected_hazard, res["detected_hazards"])
            self.assertGreaterEqual(res["urgency_score"], 0.6)

    def test_low_urgency_for_positive_or_routine(self):
        """Ensure appreciative or completed feedback resolves to Low Urgency."""
        scorer = UrgencyScorer()
        text = "Thank you BMC team for prompt service. The water pipeline is repaired and restored."
        res = scorer.score(text, sentiment_score=0.8)
        self.assertEqual(res["urgency_level"], "Low")
        self.assertLessEqual(res["urgency_score"], 0.3)

    # ---------------------------------------------------------
    # 5. Synthetic Starter Dataset Validation
    # ---------------------------------------------------------
    def test_starter_dataset_integrity(self):
        """Verify the 25 GTB Nagar items satisfy all Ward criteria."""
        items = get_starter_dataset()
        self.assertEqual(len(items), 25)

        valid_clusters = {"GTB Station", "Sardar Nagar", "Punjabi Colony", "Flank Road"}
        valid_depts = {
            "Solid Waste Management",
            "Roads & Infrastructure",
            "Water Supply & Sewage",
            "Street Lighting & Public Safety"
        }
        valid_urgencies = {"High", "Medium", "Low"}
        valid_sentiments = {"Positive", "Neutral", "Negative"}

        clusters_found = set()
        depts_found = set()
        urgencies_found = set()

        for item in items:
            self.assertIn(item["location_cluster"], valid_clusters)
            self.assertIn(item["category"], valid_depts)
            self.assertIn(item["urgency_level"], valid_urgencies)
            self.assertIn(item["sentiment_label"], valid_sentiments)
            self.assertGreaterEqual(item["sentiment_score"], -1.0)
            self.assertLessEqual(item["sentiment_score"], 1.0)
            self.assertTrue(len(item["raw_text"]) > 15)

            clusters_found.add(item["location_cluster"])
            depts_found.add(item["category"])
            urgencies_found.add(item["urgency_level"])

        # All 4 clusters and 4 departments must be represented in starter dataset
        self.assertEqual(clusters_found, valid_clusters)
        self.assertEqual(depts_found, valid_depts)
        self.assertEqual(urgencies_found, valid_urgencies)

    # ---------------------------------------------------------
    # 6. Geospatial Coordinates & Tracking Token Tests
    # ---------------------------------------------------------
    def test_coordinates_generation(self):
        """Verify GPS coordinates are centered tightly around GTB Nagar (lat ~19.03, lon ~72.86)."""
        from utils.db_manager import get_item_coordinates, GTB_NAGAR_CENTER
        clusters = ["GTB Station", "Sardar Nagar", "Punjabi Colony", "Flank Road", "Sion Koliwada"]

        for c in clusters:
            lat, lon = get_item_coordinates(1, c)
            # Must be within ~0.02 degrees of GTB Nagar center
            self.assertAlmostEqual(lat, GTB_NAGAR_CENTER["lat"], delta=0.02)
            self.assertAlmostEqual(lon, GTB_NAGAR_CENTER["lon"], delta=0.02)

    def test_tracking_token_format(self):
        """Verify tracking token conforms to BMC-FN-YYYY-XXXX format."""
        from utils.db_manager import generate_tracking_token
        token = generate_tracking_token(42)
        import re
        self.assertTrue(re.match(r"^BMC-FN-\d{4}-0042$", token))

    # ---------------------------------------------------------
    # 7. Explainable AI (XAI) & Academic Benchmark Tests
    # ---------------------------------------------------------
    def test_xai_engine_explanations(self):
        """Verify token feature attributions and department probability distributions."""
        from models.xai_engine import xai_engine, ACADEMIC_VALIDATION_METRICS

        # Sentiment feature attribution
        text = "Dangerous open manhole outside GTB Station posing an immediate accident hazard!"
        res = xai_engine.explain_full(text)
        self.assertLess(res["sentiment"]["final_polarity"], -0.3)
        self.assertGreater(len(res["sentiment"]["token_contributions"]), 0)
        self.assertEqual(res["department"]["predicted_department"], "Water Supply & Sewage")
        self.assertEqual(res["urgency"]["urgency_level"], "High")

        # Academic benchmark metrics verification
        self.assertEqual(ACADEMIC_VALIDATION_METRICS["macro_precision"], 87.2)
        self.assertEqual(ACADEMIC_VALIDATION_METRICS["macro_recall"], 84.6)
        self.assertEqual(ACADEMIC_VALIDATION_METRICS["macro_f1"], 85.8)
        self.assertEqual(len(ACADEMIC_VALIDATION_METRICS["department_breakdown"]), 4)


if __name__ == "__main__":
    unittest.main()
