"""
Database manager and data models for JAN-MANAS.
Civic Sentiment & Urgency Analyzer for BMC F-North Ward / GTB Nagar.
"""

import os
import sqlite3
from datetime import datetime
from dataclasses import dataclass, asdict
from contextlib import contextmanager
from typing import List, Dict, Any, Optional, Tuple, Generator

DEFAULT_DB_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "jan_manas.db")

VALID_CLUSTERS = [
    "GTB Station",
    "Sardar Nagar",
    "Punjabi Colony",
    "Flank Road",
    "GTB Nagar Railway Station",
    "Sardar Nagar Sector 1-4",
    "Sion Koliwada"
]
VALID_DEPARTMENTS = [
    "Solid Waste Management",
    "Roads & Infrastructure",
    "Water Supply & Sewage",
    "Street Lighting & Public Safety"
]
VALID_URGENCY = ["High", "Medium", "Low"]
VALID_SENTIMENT_LABELS = ["Positive", "Neutral", "Negative"]
VALID_STATUS = ["Pending", "In Progress", "Resolved"]

# Public-facing Citizen Locality Options
LOCALITY_OPTIONS = [
    "GTB Nagar Railway Station",
    "Sardar Nagar Sector 1-4",
    "Punjabi Colony",
    "Sion Koliwada"
]

LOCALITY_TO_CLUSTER = {
    "GTB Nagar Railway Station": "GTB Station",
    "GTB Station": "GTB Station",
    "Sardar Nagar Sector 1-4": "Sardar Nagar",
    "Sardar Nagar": "Sardar Nagar",
    "Punjabi Colony": "Punjabi Colony",
    "Sion Koliwada": "Flank Road",
    "Flank Road": "Flank Road"
}

# GPS Anchor Coordinates centered around GTB Nagar (lat: 19.0345, lon: 72.8617)
GTB_NAGAR_CENTER = {"lat": 19.0345, "lon": 72.8617}

CLUSTER_COORDINATES = {
    "GTB Station": {"lat": 19.0352, "lon": 72.8612},
    "GTB Nagar Railway Station": {"lat": 19.0352, "lon": 72.8612},
    "Sardar Nagar": {"lat": 19.0378, "lon": 72.8638},
    "Sardar Nagar Sector 1-4": {"lat": 19.0378, "lon": 72.8638},
    "Punjabi Colony": {"lat": 19.0332, "lon": 72.8592},
    "Flank Road": {"lat": 19.0315, "lon": 72.8642},
    "Sion Koliwada": {"lat": 19.0315, "lon": 72.8642}
}


def get_item_coordinates(item_id: int, cluster: str) -> Tuple[float, float]:
    """Calculate deterministic GPS coordinates with street jitter around neighborhood center."""
    anchor = CLUSTER_COORDINATES.get(cluster, GTB_NAGAR_CENTER)
    import hashlib
    # Deterministic hash based on ID and cluster
    h = int(hashlib.md5(f"jan_manas_geo_{item_id}_{cluster}".encode()).hexdigest()[:8], 16)
    lat_jitter = (((h % 1000) / 1000.0) - 0.5) * 0.0028
    lon_jitter = ((((h // 1000) % 1000) / 1000.0) - 0.5) * 0.0028
    return round(anchor["lat"] + lat_jitter, 6), round(anchor["lon"] + lon_jitter, 6)


def generate_tracking_token(item_id: int) -> str:
    """Generate official BMC citizen grievance tracking token."""
    year = datetime.now().year
    return f"BMC-FN-{year}-{item_id:04d}"


@dataclass
class CivicFeedback:
    raw_text: str
    location_cluster: str
    category: str
    sentiment_score: float
    sentiment_label: str
    urgency_level: str
    status: str = "Pending"
    timestamp: Optional[str] = None
    id: Optional[int] = None

    def to_dict(self) -> Dict[str, Any]:
        data = asdict(self)
        if not data.get("timestamp"):
            data["timestamp"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        return data


class DatabaseManager:
    """SQLite helper for managing JAN-MANAS civic feedback records."""

    def __init__(self, db_path: Optional[str] = None):
        self.db_path = db_path or DEFAULT_DB_PATH
        # Ensure parent directory exists
        db_dir = os.path.dirname(self.db_path)
        if db_dir and not os.path.exists(db_dir):
            os.makedirs(db_dir, exist_ok=True)
        self.init_db()

    @contextmanager
    def get_connection(self) -> Generator[sqlite3.Connection, None, None]:
        """Create, yield, and automatically close a SQLite connection."""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
        finally:
            conn.close()

    def init_db(self) -> None:
        """Create the schema and helpful indexes if they do not exist."""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS civic_feedback (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL,
                    location_cluster TEXT NOT NULL,
                    raw_text TEXT NOT NULL,
                    category TEXT NOT NULL,
                    sentiment_score REAL NOT NULL,
                    sentiment_label TEXT NOT NULL,
                    urgency_level TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'Pending'
                );
            """)

            # Create indexing for rapid dashboard queries & Ward filtering
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_cluster ON civic_feedback(location_cluster);")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_urgency ON civic_feedback(urgency_level);")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_category ON civic_feedback(category);")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_status ON civic_feedback(status);")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_timestamp ON civic_feedback(timestamp);")
            conn.commit()

    def insert_feedback(
        self,
        raw_text: str,
        location_cluster: str,
        category: str,
        sentiment_score: float,
        sentiment_label: str,
        urgency_level: str,
        status: str = "Pending",
        timestamp: Optional[str] = None
    ) -> int:
        """Insert a single civic feedback record and return its ID."""
        ts = timestamp or datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # Validation fallbacks
        if location_cluster not in VALID_CLUSTERS:
            # Default to nearest or GTB Station if unknown
            location_cluster = "GTB Station"
        if status not in VALID_STATUS:
            status = "Pending"
        if urgency_level not in VALID_URGENCY:
            urgency_level = "Medium"
        if sentiment_label not in VALID_SENTIMENT_LABELS:
            sentiment_label = "Neutral"

        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO civic_feedback (
                    timestamp, location_cluster, raw_text, category,
                    sentiment_score, sentiment_label, urgency_level, status
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                ts, location_cluster, raw_text.strip(), category,
                float(sentiment_score), sentiment_label, urgency_level, status
            ))
            conn.commit()
            return cursor.lastrowid

    def bulk_insert_feedback(self, items: List[Dict[str, Any]]) -> int:
        """Insert multiple feedback items within a single atomic transaction."""
        inserted_count = 0
        with self.get_connection() as conn:
            cursor = conn.cursor()
            for it in items:
                ts = it.get("timestamp") or datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                cluster = it.get("location_cluster", "GTB Station")
                if cluster not in VALID_CLUSTERS:
                    cluster = "GTB Station"
                status = it.get("status", "Pending")
                if status not in VALID_STATUS:
                    status = "Pending"
                urgency = it.get("urgency_level", "Medium")
                if urgency not in VALID_URGENCY:
                    urgency = "Medium"
                s_label = it.get("sentiment_label", "Neutral")
                if s_label not in VALID_SENTIMENT_LABELS:
                    s_label = "Neutral"

                cursor.execute("""
                    INSERT INTO civic_feedback (
                        timestamp, location_cluster, raw_text, category,
                        sentiment_score, sentiment_label, urgency_level, status
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    ts,
                    cluster,
                    it["raw_text"].strip(),
                    it.get("category", "General Civic Issues"),
                    float(it.get("sentiment_score", 0.0)),
                    s_label,
                    urgency,
                    status
                ))
                inserted_count += 1
            conn.commit()
        return inserted_count

    def get_all_feedback(
        self,
        cluster: Optional[str] = None,
        category: Optional[str] = None,
        urgency: Optional[str] = None,
        status: Optional[str] = None,
        search_query: Optional[str] = None,
        limit: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        """Retrieve feedback items with optional filtering and sorting."""
        query = "SELECT * FROM civic_feedback WHERE 1=1"
        params: List[Any] = []

        if cluster and cluster != "All":
            query += " AND location_cluster = ?"
            params.append(cluster)
        if category and category != "All":
            query += " AND category = ?"
            params.append(category)
        if urgency and urgency != "All":
            query += " AND urgency_level = ?"
            params.append(urgency)
        if status and status != "All":
            query += " AND status = ?"
            params.append(status)
        if search_query:
            query += " AND raw_text LIKE ?"
            params.append(f"%{search_query.strip()}%")

        query += " ORDER BY id DESC"

        if limit and limit > 0:
            query += " LIMIT ?"
            params.append(limit)

        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(query, tuple(params))
            rows = cursor.fetchall()
            return [dict(row) for row in rows]

    def get_feedback_by_id(self, item_id: int) -> Optional[Dict[str, Any]]:
        """Fetch a single record by its ID."""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM civic_feedback WHERE id = ?", (item_id,))
            row = cursor.fetchone()
            return dict(row) if row else None

    def update_status(self, item_id: int, new_status: str) -> bool:
        """Update the workflow status of an existing feedback item."""
        if new_status not in VALID_STATUS:
            raise ValueError(f"Invalid status '{new_status}'. Allowed: {VALID_STATUS}")

        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE civic_feedback
                SET status = ?
                WHERE id = ?
            """, (new_status, item_id))
            conn.commit()
            return cursor.rowcount > 0

    def delete_feedback(self, item_id: int) -> bool:
        """Delete a feedback entry by ID."""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM civic_feedback WHERE id = ?", (item_id,))
            conn.commit()
            return cursor.rowcount > 0

    def get_count(self) -> int:
        """Get the total count of feedback items stored."""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM civic_feedback")
            return cursor.fetchone()[0]

    def get_analytics_summary(self) -> Dict[str, Any]:
        """Aggregate summary metrics for the executive BMC F-North dashboard."""
        with self.get_connection() as conn:
            cursor = conn.cursor()

            # Total count
            cursor.execute("SELECT COUNT(*) FROM civic_feedback")
            total = cursor.fetchone()[0]

            # Urgency breakdown
            cursor.execute("""
                SELECT urgency_level, COUNT(*)
                FROM civic_feedback
                GROUP BY urgency_level
            """)
            urgency_counts = {level: 0 for level in VALID_URGENCY}
            for row in cursor.fetchall():
                urgency_counts[row[0]] = row[1]

            # Department breakdown
            cursor.execute("""
                SELECT category, COUNT(*)
                FROM civic_feedback
                GROUP BY category
            """)
            category_counts = {row[0]: row[1] for row in cursor.fetchall()}

            # Sentiment label breakdown
            cursor.execute("""
                SELECT sentiment_label, COUNT(*)
                FROM civic_feedback
                GROUP BY sentiment_label
            """)
            sentiment_counts = {label: 0 for label in VALID_SENTIMENT_LABELS}
            for row in cursor.fetchall():
                sentiment_counts[row[0]] = row[1]

            # Cluster breakdown
            cursor.execute("""
                SELECT location_cluster, COUNT(*), AVG(sentiment_score)
                FROM civic_feedback
                GROUP BY location_cluster
            """)
            cluster_stats = {}
            for row in cursor.fetchall():
                cluster_stats[row[0]] = {
                    "count": row[1],
                    "avg_sentiment": round(row[2], 2) if row[2] is not None else 0.0
                }

            # Status breakdown
            cursor.execute("""
                SELECT status, COUNT(*)
                FROM civic_feedback
                GROUP BY status
            """)
            status_counts = {st: 0 for st in VALID_STATUS}
            for row in cursor.fetchall():
                status_counts[row[0]] = row[1]

            # Average sentiment overall
            cursor.execute("SELECT AVG(sentiment_score) FROM civic_feedback")
            avg_sentiment_row = cursor.fetchone()[0]
            avg_sentiment = round(avg_sentiment_row, 3) if avg_sentiment_row is not None else 0.0

            return {
                "total_feedbacks": total,
                "average_sentiment": avg_sentiment,
                "urgency_distribution": urgency_counts,
                "category_distribution": category_counts,
                "sentiment_distribution": sentiment_counts,
                "cluster_distribution": cluster_stats,
                "status_distribution": status_counts
            }

    def seed_database_if_empty(self) -> int:
        """Check if DB is empty; if so, populate with 25 synthetic starter items."""
        count = self.get_count()
        if count == 0:
            # Import starter dataset
            from data.starter_dataset import get_starter_dataset
            starter_items = get_starter_dataset()
            return self.bulk_insert_feedback(starter_items)
        return 0

    def reset_database(self) -> None:
        """Clear the civic_feedback table."""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM civic_feedback")
            cursor.execute("DELETE FROM sqlite_sequence WHERE name='civic_feedback'")
            conn.commit()
