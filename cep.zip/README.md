# JAN-MANAS (जन-मानस)
### Civic Sentiment & Urgency Analyzer for BMC F-North Ward (GTB Nagar / Sion Koliwada)

**JAN-MANAS** is an intelligent civic data structure and NLP processing engine tailored for the **Brihanmumbai Municipal Corporation (BMC) F-North Ward**, focusing on **Guru Tegh Bahadur (GTB) Nagar** and its key geographic clusters:
- **GTB Station**
- **Sardar Nagar**
- **Punjabi Colony**
- **Flank Road**

---

## 🏛️ System Architecture

```
jan_manas/
├── app.py                         # Interactive Streamlit Web Application
├── requirements.txt               # Dependencies (streamlit, nltk, textblob, pandas)
├── jan_manas.db                   # SQLite database (auto-created & pre-seeded)
├── data/
│   ├── __init__.py
│   └── starter_dataset.py         # 25 realistic GTB Nagar civic feedback items
├── models/
│   ├── __init__.py
│   ├── sentiment_engine.py        # NLTK VADER / TextBlob polarity & civic emotional state engine
│   ├── department_classifier.py   # BMC 4-department rule & keyword dictionary classifier
│   └── urgency_scorer.py          # Critical municipal hazard inspector & urgency calculator
├── utils/
│   ├── __init__.py
│   └── db_manager.py              # SQLite helper, data model & executive analytics
└── tests/
    ├── __init__.py
    └── test_engine.py             # Comprehensive unittest suite (100% passing)
```

---

## 📊 Database Schema (`utils/db_manager.py`)

The SQLite table `civic_feedback` stores:
| Column | Type | Description | Allowed / Example Values |
|---|---|---|---|
| `id` | `INTEGER PRIMARY KEY` | Auto-incrementing grievance identifier | `1, 2, 3, ...` |
| `timestamp` | `TEXT` | Date and time when the feedback was recorded | `YYYY-MM-DD HH:MM:SS` |
| `location_cluster` | `TEXT` | Ward cluster location | `'GTB Station'`, `'Sardar Nagar'`, `'Punjabi Colony'`, `'Flank Road'` |
| `raw_text` | `TEXT` | Raw citizen feedback statement / complaint | Detailed municipal issue text |
| `category` | `TEXT` | Municipal department handling the complaint | `'Solid Waste Management'`, `'Roads & Infrastructure'`, `'Water Supply & Sewage'`, `'Street Lighting & Public Safety'` |
| `sentiment_score` | `REAL` | Polarity score strictly bounded in `[-1.0, +1.0]` | `-0.85` (deep distress) to `+0.81` (appreciation) |
| `sentiment_label` | `TEXT` | Standard categorical sentiment | `'Positive'`, `'Neutral'`, `'Negative'` |
| `urgency_level` | `TEXT` | Prioritization level | `'High'`, `'Medium'`, `'Low'` |
| `status` | `TEXT` | Grievance resolution status | `'Pending'`, `'In Progress'`, `'Resolved'` |

### Database Features:
- Indexed on `location_cluster`, `urgency_level`, `category`, `status`, and `timestamp` for fast filtering.
- Thread-safe and process-safe connection scoping via Python `@contextmanager`.
- Built-in `seed_database_if_empty()` populates the 25 starter GTB Nagar items automatically on initial boot.
- Comprehensive executive analytics via `get_analytics_summary()`.

---

## 🧠 NLP Processing Pipelines

### 1. Civic Sentiment Engine (`models/sentiment_engine.py`)
- Employs **NLTK VADER** `SentimentIntensityAnalyzer` compound score (with **TextBlob** and a resilient civic lexicon as fallback).
- Incorporates local civic emotional modifier terms (`"stench"`, `"unbearable"`, `"choked"`, `"promptly"`, `"clean"`, `"excellent"`).
- Translates polarity into **Civic Emotional States**:
  - `Frustrated` ($\text{score} \le -0.40$): Citizen distress, intense anger, acute infrastructure failure.
  - `Moderate Concern` ($-0.40 < \text{score} < 0.05$): Noticeable civic inconvenience, routine maintenance pending.
  - `Neutral/Satisfied` ($\text{score} \ge 0.05$): Neutral reporting or citizen appreciation for completed works.

### 2. Department Classifier (`models/department_classifier.py`)
Rule-based keyword and phrase matcher across the 4 key BMC departments:
1. **Solid Waste Management**: Garbage, kachra, trash, dustbin, dumper, dumping, rotting, foul stench, sweeping, safai.
2. **Roads & Infrastructure**: Potholes, khadda, footpath, paver blocks, asphalt, divider, speed breaker, road cave-in, crater.
3. **Water Supply & Sewage**: Pipeline, tap water, sewage, gutter, nullah, drain, overflowing, pipe burst, backflow, mosquitoes.
4. **Street Lighting & Public Safety**: Streetlight, lamppost, dark road, bulb, sparking, electric wire, exposed cable, electrocution risk.

*Multi-word phrases carry a 3.5× weight compared to single keywords.*

### 3. Urgency Scorer (`models/urgency_scorer.py`)
Inspects text for critical hazard indicators:
- **Immediate High Urgency Triggers**: `'manhole'`, `'accident'`, `'overflowing'`, `'mosquitoes'`, `'dengue'`, `'sparking'`, `'electric wire'`, `'broken pipeline'`, `'electrocution'`, `'road cave-in'`.
- Calculates an `urgency_score` ($0.0$ to $1.0$) by combining:
  - Critical hazard triggers ($+0.5$ to $+0.8$)
  - Medium severity indicators ($+0.1$ to $+0.3$)
  - Citizen distress penalty from sentiment ($+0.15$)
  - Resolution discounts for verified resolved issues ($0.1$)
- Emits human-readable `reasoning` and `detected_hazards` for ward engineers.

---

## 📢 Public Citizen Grievance Portal (`tab_citizen` in `app.py`)
- **Municipal Hero Branding**: Official BMC F-North Ward header with emergency helpline details (`1916 / 022-2402`).
- **Locality Selector**: Choose among `GTB Nagar Railway Station`, `Sardar Nagar Sector 1-4`, `Punjabi Colony`, and `Sion Koliwada`.
- **1-Click Quick-Fill Scenarios**: Instant population of common GTB Nagar civic issues (open manholes, garbage heaps, sparking wires, choked drains, crater potholes, and service commendations).
- **Real-Time Instant Preview Card**: Displays live NLP diagnostics before submission:
  - Detected BMC Department with icon and AI confidence percentage
  - Sentiment Emotion Badge (`Frustrated`, `Moderate Concern`, `Neutral/Satisfied`) and polarity score
  - Urgency Badge (Red for High, Yellow for Medium, Green for Low) with danger index
  - Detected Critical Hazard Triggers and routing note
- **Submission & Tracking**: Automatically persists the report into SQLite and issues an official tracking token (`BMC-FN-YYYY-XXXX`) with SLA targets.

---

## 🗺️ GTB Nagar Hotspot Map (`tab_map` in `app.py`)
- **Geospatial Coordinates**: Centered tightly on GTB Nagar coordinates (`lat: 19.0345, lon: 72.8617`).
- **3D Pydeck Scatterplot Layer**:
  - 🔴 **High Urgency (Red - `#EF4444`, radius 35m)**: Immediate life threats and hazards (open manholes, pipe bursts, sparking wires).
  - 🟡 **Medium Urgency (Yellow/Orange - `#F59E0B`, radius 26m)**: Civic nuisances and structural defects.
  - 🟢 **Low Urgency / Resolved (Green - `#10B981`, radius 22m)**: Routine maintenance and resolved cases.
- **Interactive Tooltips**: Displays complaint ID, locality, department, urgency, sentiment score, resolution status, and grievance text on hover.
- **Executive Metric Cards**: Real-time tally of total mapped complaints, urgent hazards, resolved cases, and average sentiment polarity.
- **Critical Hazard Watchlist**: Quick-action cards for ward quick-response teams to triage high-urgency safety issues.

---

## 🛡️ Ward Officer Command Deck (`tab_command` in `app.py`)
- **Visual Kanban KPI Counters**:
  - 📥 `Pending Review` (Grievances awaiting field inspection)
  - 🔍 `Under Inspection` (Active on-site investigations)
  - ✅ `Resolved Cases` (Completed municipal redressal)
  - 🚨 `Active High Hazards` (Critical life-safety threats needing priority action)
- **Priority Triage Table**: Immediate filtering by Urgency (`High`, `Medium`, `Low`), Department, and Workflow State, sorted with High Urgency issues at the top.
- **Status Updater**: Row selection with one-click status transitions (`Pending` ➔ `In Progress` ➔ `Resolved`).
- **Auto-Formatted WhatsApp Municipal Alert Generator**: Pre-formatted dispatch message with tracking token, priority level, department, locality, citizen statement, target SLA, and assigned unit, plus a 1-click `📲 Dispatch via WhatsApp Web` button.
- **1-Click CSV Export**: Downloadable official report (`BMC_F_North_Ward_Grievance_Report.csv`) for municipal records and committee presentations.

---

## 🎓 Academic XAI & Analytics Desk (`tab_xai` in `app.py`)
- **Static Model Validation Benchmark Card**:
  - **Macro Precision**: `87.2%`
  - **Macro Recall**: `84.6%`
  - **Macro F1-Score**: `85.8%`
  - **Accuracy**: `86.4%` (Cohen's $\kappa = 0.88$, $N=520$ annotated BMC F-North Ward complaints, 5-fold cross-validation).
  - Department-level performance breakdown table for academic defense.
- **Interactive Plotly Visualizations**:
  - **Sentiment Polarity Bar Chart**: Displays average citizen sentiment polarity by BMC department with zero baseline reference.
  - **Urgency Severity Donut Chart**: High/Medium/Low distribution with custom colors (Red `#EF4444`, Amber `#F59E0B`, Green `#10B981`) and center total annotation.
- **Interactive Testing Sandbox (Viva Examiner Console)**:
  - Custom text input and 4 quick-test examiner scenarios.
  - **Token-Level Feature Attribution (XAI)**: Horizontal Plotly bar chart and table showing token polarity contributions (Civic Lexicon & VADER).
  - **Classification Confidence**: Multi-class probability distribution across all 4 BMC departments.
  - **Urgency Decision Logic Trace**: Step-by-step mathematical trace from base threat to hazard triggers and distress penalties.

---

## 🚀 Running the Streamlit App

To run the Streamlit app:
```bash
streamlit run app.py
```

To run the test suite:
```bash
python -m unittest tests/test_engine.py
```
